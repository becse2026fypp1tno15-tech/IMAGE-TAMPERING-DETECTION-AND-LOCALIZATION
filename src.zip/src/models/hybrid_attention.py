# src/models/hybrid_attention.py
"""
Hybrid Attention Module (HAM) following the base paper:
- Channel Attention (SE-like MLP)
- Spatial (non-local) self-attention
- Residual fusion to produce enhanced c5_hat

Inputs:
 - feat: tensor (B, C, H, W) (c5 from backbone)

Output:
 - feat_hat: tensor (B, C, H, W)
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class ChannelAttention(nn.Module):
    """SE-style channel attention with reduction r."""
    def __init__(self, channels, reduction=16):
        super().__init__()
        self.gap = nn.AdaptiveAvgPool2d(1)
        mid = max(1, channels // reduction)
        self.fc = nn.Sequential(
            nn.Conv2d(channels, mid, kernel_size=1, bias=True),
            nn.ReLU(inplace=True),
            nn.Conv2d(mid, channels, kernel_size=1, bias=True),
            nn.Sigmoid()
        )

    def forward(self, x):
        # x: (B, C, H, W)
        s = self.gap(x)          # (B, C, 1, 1)
        w = self.fc(s)           # (B, C, 1, 1) in (0,1)
        return x * w             # scale channels


class NonLocalSpatialAttention(nn.Module):
    """
    Non-local / self-attention block (spatial).
    Returns a residual-style attended feature with same channels as input.
    Implementation follows 'Non-local Neural Networks' (Wang et al.)
    Lightweight variant: uses 1x1 convs to reduce dims.
    """
    def __init__(self, in_channels, inter_channels=None):
        super().__init__()
        if inter_channels is None:
            inter_channels = max(1, in_channels // 2)

        self.g = nn.Conv2d(in_channels, inter_channels, kernel_size=1, bias=False)
        self.theta = nn.Conv2d(in_channels, inter_channels, kernel_size=1, bias=False)
        self.phi = nn.Conv2d(in_channels, inter_channels, kernel_size=1, bias=False)

        self.W = nn.Conv2d(inter_channels, in_channels, kernel_size=1, bias=False)
        # initialize W to zeros for residual learning stability
        nn.init.constant_(self.W.weight, 0.0)

    def forward(self, x):
        # x: (B, C, H, W)
        B, C, H, W = x.shape
        g_x = self.g(x).view(B, -1, H*W)          # (B, inter, N)
        g_x = g_x.permute(0, 2, 1)                # (B, N, inter)

        theta_x = self.theta(x).view(B, -1, H*W)  # (B, inter, N)
        theta_x = theta_x.permute(0, 2, 1)        # (B, N, inter)

        phi_x = self.phi(x).view(B, -1, H*W)      # (B, inter, N)

        # compute affinity
        f = torch.matmul(theta_x, phi_x)          # (B, N, N)
        f_div_C = F.softmax(f, dim=-1)            # softmax along last dim

        # aggregate
        y = torch.matmul(f_div_C, g_x)            # (B, N, inter)
        y = y.permute(0, 2, 1).contiguous()       # (B, inter, N)
        y = y.view(B, -1, H, W)                   # (B, inter, H, W)

        W_y = self.W(y)                           # (B, C, H, W)
        # Residual-style return
        return W_y


class HybridAttention(nn.Module):
    """
    Hybrid Attention Module:
      - Channel Attention (CAM)
      - Spatial Non-Local Attention (SAM)
      - Fuse residually: out = x + cam(x) + sam(x)
    """
    def __init__(self, in_channels, reduction=16):
        super().__init__()
        self.cam = ChannelAttention(in_channels, reduction=reduction)
        self.sam = NonLocalSpatialAttention(in_channels)

        # small conv to smooth the fusion (optional but stabilizes)
        self.fusion_conv = nn.Sequential(
            nn.Conv2d(in_channels, in_channels, kernel_size=1, bias=False),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        # Channel attention
        cam_out = self.cam(x)          # (B, C, H, W)

        # Spatial attention (non-local)
        sam_out = self.sam(x)          # (B, C, H, W)

        # Residual fusion
        fused = x + cam_out + sam_out

        out = self.fusion_conv(fused)
        return out
