# src/data/transforms.py
# Preprocessing EXACTLY as used in base paper:
# Resize → (optional) Color jitter → Flip → Normalize → GT boundary (dilate - erode)

from PIL import Image, ImageEnhance
import numpy as np
import torch
import torch.nn.functional as F

IMAGENET_MEAN = [0.485, 0.456, 0.406]
IMAGENET_STD  = [0.229, 0.224, 0.225]


def pil_to_tensor(img_pil):
    """Convert PIL RGB image to Torch tensor (C,H,W), float32 in [0,1]."""
    arr = np.asarray(img_pil).astype(np.float32) / 255.0  # H,W,C
    if arr.ndim == 2:
        arr = np.expand_dims(arr, axis=-1)
    arr = arr[..., :3]  
    arr = arr.transpose(2,0,1)  
    return torch.from_numpy(arr).float()


def normalize_tensor(tensor):
    """Normalize ImageNet-style."""
    mean = torch.tensor(IMAGENET_MEAN).view(-1,1,1)
    std  = torch.tensor(IMAGENET_STD).view(-1,1,1)
    return (tensor - mean) / std


class Preprocessor:
    def __init__(self, input_size=512, train=True):
        self.input_size = input_size
        self.train = train

    def _resize(self, img, mask):
        img  = img.resize((self.input_size, self.input_size), Image.BILINEAR)
        mask = mask.resize((self.input_size, self.input_size), Image.NEAREST)
        return img, mask

    def _color_jitter(self, img):
        if torch.rand(1) < 0.7:
            img = ImageEnhance.Brightness(img).enhance(1 + (torch.rand(1).item() - 0.5) * 0.4)
        if torch.rand(1) < 0.7:
            img = ImageEnhance.Contrast(img).enhance(1 + (torch.rand(1).item() - 0.5) * 0.4)
        return img

    def _random_flip(self, img, mask):
        if torch.rand(1) < 0.5:
            img  = img.transpose(Image.FLIP_LEFT_RIGHT)
            mask = mask.transpose(Image.FLIP_LEFT_RIGHT)
        return img, mask

    def _mask_to_boundary(self, mask_tensor, k=5):
        """Dilation - Erosion to produce boundary GT."""
        x = mask_tensor.unsqueeze(0)   # (1,1,H,W)
        pad = k // 2

        dil = F.max_pool2d(x, kernel_size=k, stride=1, padding=pad)
        inv = 1 - x
        ero_inv = F.max_pool2d(inv, kernel_size=k, stride=1, padding=pad)
        ero = 1 - ero_inv

        return (dil - ero).clamp(0,1).squeeze(0)  # (1,H,W)

    def __call__(self, img, mask):
        img, mask = self._resize(img, mask)

        if self.train:
            img = self._color_jitter(img)
            img, mask = self._random_flip(img, mask)

        img_t  = pil_to_tensor(img)
        img_t  = normalize_tensor(img_t)

        mask_arr = np.array(mask).astype(np.float32)
        mask_t = torch.from_numpy((mask_arr > 127).astype(np.float32)).unsqueeze(0)

        boundary = self._mask_to_boundary(mask_t)

        return img_t, mask_t, boundary
