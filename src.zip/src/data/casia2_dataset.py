# src/data/casia2_dataset.py

import os
from PIL import Image
from torch.utils.data import Dataset

from .transforms import Preprocessor

class CASIA2Dataset(Dataset):
    """
    Correct CASIA2 loader:
    - Loads ONLY tampered images from Tp/
    - Matches them with masks ending in '_gt.png'
    """

    def __init__(self, root, input_size=512, train=True):
        """
        root structure must contain:
            CASIA2/
              ├── Tp/
              └── CASIA 2 Groundtruth/
        """
        self.tp_dir = os.path.join(root, "Tp")
        self.gt_dir = os.path.join(root, "CASIA 2 Groundtruth")

        # -------------------------------------
        # Debug prints
        # -------------------------------------
        print("DEBUG: tp_dir =", self.tp_dir)
        print("DEBUG: gt_dir =", self.gt_dir)
        print("DEBUG: Exists Tp?  ", os.path.exists(self.tp_dir))
        print("DEBUG: Exists GT?  ", os.path.exists(self.gt_dir))

        print("\nDEBUG: Listing Tp folder (first 20 files):")
        print(os.listdir(self.tp_dir)[:20])

        print("\nDEBUG: Listing GT folder (first 20 files):")
        print(os.listdir(self.gt_dir)[:20])

        # -------------------------------------
        # STEP 1: Build groundtruth lookup
        # Map: base_name → mask_path
        # Mask filename format: <basename>_gt.png
        # -------------------------------------
        self.gt_map = {}
        for fname in os.listdir(self.gt_dir):
            if fname.lower().endswith("_gt.png"):
                base = fname[:-7]   # remove "_gt.png"
                mask_path = os.path.join(self.gt_dir, fname)
                self.gt_map[base] = mask_path

        print(f"\nDEBUG: Found {len(self.gt_map)} groundtruth masks in GT folder.")

        # -------------------------------------
        # STEP 2: Pair each image with its mask
        # -------------------------------------
        self.files = []

        for img_name in os.listdir(self.tp_dir):
            if img_name.lower().endswith((".jpg", ".jpeg", ".png", ".tif")):

                base = os.path.splitext(img_name)[0]  # remove extension

                if base in self.gt_map:
                    img_path = os.path.join(self.tp_dir, img_name)
                    mask_path = self.gt_map[base]
                    self.files.append((img_path, mask_path))

        print(f"[CASIA2] Loaded {len(self.files)} paired tampered samples.\n")

        # -------------------------------------
        # Preprocessor initialization
        # -------------------------------------
        self.preproc = Preprocessor(input_size=input_size, train=train)

    # -----------------------------------------
    def __len__(self):
        return len(self.files)

    # -----------------------------------------
    def __getitem__(self, idx):
        img_path, mask_path = self.files[idx]

        img = Image.open(img_path).convert("RGB")
        mask = Image.open(mask_path).convert("L")

        img_t, mask_t, boundary_t = self.preproc(img, mask)

        return {
            "image": img_t,
            "mask": mask_t,
            "boundary": boundary_t,
            "img_path": img_path,
            "mask_path": mask_path
        }
