"""
Sampler-aware pixel-level contrastive loss (paper-faithful).

This version integrates:
 - boundary-guided sampling (sample_hard_examples)
 - hard positives / hard negatives
 - prototype-based contrastive objective

API expected by test_06_losses.py:

sampler_contrastive_loss(
    features,        # (B, C, Hf, Wf)
    mask_gt,         # (B, 1, Hin, Win)
    sampler_fn,      # function: sample_hard_examples
    Z=500,
    L=256,
    dilation=3,
    temperature=0.1,
    device=None
) -> (loss, info_dict)
"""

import torch
import torch.nn.functional as F


def sampler_contrastive_loss(
        features,
        mask_gt,
        sampler_fn,
        Z=500,
        L=256,
        dilation=3,
        temperature=0.1,
        device=None
):
    """
    features: (B, C, H, W)
    mask_gt:  (B, 1, H_in, W_in)
    sampler_fn: boundary-guided sampler function (sample_hard_examples)

    Returns:
        loss: scalar tensor
        info: dict (num_pos, num_neg per batch, etc.)
    """

    device = features.device if device is None else device
    B, C, Hf, Wf = features.shape

    # -------------------------------------------------------
    # run boundary-guided sampler
    # -------------------------------------------------------
    sampled_list = sampler_fn(
        features=features,
        mask_gt=mask_gt,
        Z=Z,
        L=L,
        dilation=dilation,
        device=device
    )

    total_loss = []
    info_all = []

    for b in range(B):
        sample = sampled_list[b]

        pos_feats = sample["pos_feats"]      # (<=L, C)
        neg_feats = sample["neg_feats"]      # (<=L, C)

        if pos_feats.numel() == 0 or neg_feats.numel() == 0:
            # no valid samples → contribute zero
            continue

        # -------------------------------------------------------
        # prototypes
        # -------------------------------------------------------
        p_pos = pos_feats.mean(dim=0, keepdim=True)  # (1, C)
        p_neg = neg_feats.mean(dim=0, keepdim=True)  # (1, C)

        # normalize
        pos_norm = F.normalize(pos_feats, dim=1)
        p_pos_norm = F.normalize(p_pos, dim=1)
        p_neg_norm = F.normalize(p_neg, dim=1)

        # similarities
        sim_pos = (pos_norm @ p_pos_norm.t()).squeeze(1) / temperature
        sim_neg = (pos_norm @ p_neg_norm.t()).squeeze(1) / temperature

        logits = torch.stack([sim_pos, sim_neg], dim=1)  # (P, 2)
        labels = torch.zeros(logits.shape[0], dtype=torch.long, device=device)

        loss = F.cross_entropy(logits, labels, reduction="mean")
        total_loss.append(loss)

        info_all.append({
            "num_pos": int(pos_feats.shape[0]),
            "num_neg": int(neg_feats.shape[0])
        })

    if len(total_loss) == 0:
        return torch.tensor(0.0, device=device, requires_grad=True), {}

    return torch.stack(total_loss).mean(), {"details": info_all}
