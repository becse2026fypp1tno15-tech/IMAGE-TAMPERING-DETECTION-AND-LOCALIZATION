# src/test/test_07_heads.py
"""
Test script for MaskHead, BoundaryHead, and ImageLevelHead.

Run from src:
    python -m test.test_07_heads
or from src/test:
    python test_07_heads.py
"""

import os
import sys
import torch
import matplotlib.pyplot as plt
import torch.nn.functional as F

# Make src importable when running from src/test
HERE = os.path.dirname(__file__)
SRC_ROOT = os.path.abspath(os.path.join(HERE, ".."))
if SRC_ROOT not in sys.path:
    sys.path.insert(0, SRC_ROOT)

from data.casia2_dataset import CASIA2Dataset
from models.backbone import ResNet50Backbone
from models.hybrid_attention import HybridAttention
from models.decoder import SimpleDecoder
from models.heads import MaskHead, BoundaryHead, ImageLevelHead

def show_img(tensor, title="Image"):
    mean = torch.tensor([0.485,0.456,0.406]).view(3,1,1)
    std  = torch.tensor([0.229,0.224,0.225]).view(3,1,1)
    img = (tensor * std + mean).clamp(0,1)
    img = img.permute(1,2,0).cpu().numpy()
    plt.figure(figsize=(4,4))
    plt.imshow(img)
    plt.title(title)
    plt.axis('off')
    plt.show()

def show_mask(arr, title="Mask"):
    plt.figure(figsize=(4,4))
    plt.imshow(arr, cmap='gray')
    plt.title(title)
    plt.axis('off')
    plt.show()

def main():
    casia_root = os.path.abspath(os.path.join(SRC_ROOT, "..", "data", "CASIA2"))
    dataset = CASIA2Dataset(root=casia_root, input_size=512, train=False)

    # pick a sample
    sample = dataset[0]
    img = sample["image"].unsqueeze(0)   # (1,3,512,512)
    mask_gt = sample["mask"].unsqueeze(0)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("Using device:", device)

    # backbone -> ham -> decoder
    backbone = ResNet50Backbone(pretrained=True).to(device)
    ham = HybridAttention(in_channels=2048).to(device)
    decoder = SimpleDecoder().to(device)

    backbone.eval(); ham.eval(); decoder.eval()

    with torch.no_grad():
        feats = backbone(img.to(device))
        c5_hat = ham(feats['c5'])
        mask_logits_up, boundaries, final_feat = decoder({'c2':feats['c2'], 'c3':feats['c3'], 'c4':feats['c4']},
                                                         c5_hat, input_size=(512,512))

    print("decoder final feature shape:", tuple(final_feat.shape))
    print("mask_logits_up shape (from decoder):", tuple(mask_logits_up.shape))
    print("boundaries shapes:", {k:tuple(v.shape) for k,v in boundaries.items()})

    # instantiate heads
    mask_head = MaskHead(in_channels=final_feat.shape[1]).to(device)
    boundary_head = BoundaryHead(in_channels=final_feat.shape[1]).to(device)
    img_head = ImageLevelHead(in_channels=c5_hat.shape[1]).to(device)

    mask_logits_local = mask_head(final_feat)   # (B,1,H2,W2) e.g., (1,1,128,128)
    print("MaskHead local logits shape:", tuple(mask_logits_local.shape))

    # upsample to input size
    mask_logits_local_up = mask_head.upsample_to(mask_logits_local, size=(512,512))
    print("MaskHead upsampled to input:", tuple(mask_logits_local_up.shape))

    # get probabilities for visualization
    # ----- IMPORTANT: detach before converting to numpy -----
    mask_prob = torch.sigmoid(mask_logits_local_up).detach().squeeze(0).squeeze(0).cpu().numpy()

    # boundary head
    boundary_logits_local = boundary_head(final_feat)
    print("BoundaryHead local logits shape:", tuple(boundary_logits_local.shape))

    # image-level head (on c5_hat)
    img_logit = img_head(c5_hat.to(device))   # (B,1)
    print("ImageLevelHead logit shape:", tuple(img_logit.shape))
    print("Image-level logit value:", float(img_logit.cpu().squeeze().item()))

    # show visuals
    show_img(sample["image"], "Input Image (preprocessed)")
    show_mask(mask_prob, "MaskHead predicted mask (prob)")

    # visualize boundary predicted by boundary head (upsampled)
    b_up = F.interpolate(boundary_logits_local,
                         size=(512,512),
                         mode='bilinear',
                         align_corners=False).detach()
    show_mask(b_up.squeeze().cpu().numpy(), "BoundaryHead logits upsampled")


if __name__ == "__main__":
    main()
