# src/test/test_10_fullmodel.py
"""
Unit test for models/full_model.py
Run from src/test:
    python test_10_fullmodel.py
"""

import os
import sys
import torch
import matplotlib.pyplot as plt

HERE = os.path.dirname(__file__)
SRC_ROOT = os.path.abspath(os.path.join(HERE, ".."))
if SRC_ROOT not in sys.path:
    sys.path.insert(0, SRC_ROOT)

from data.casia2_dataset import CASIA2Dataset
from models.full_model import FullModel

def main():
    casia_root = os.path.abspath(os.path.join(SRC_ROOT, "..", "data", "CASIA2"))
    dataset = CASIA2Dataset(root=casia_root, input_size=512, train=False)
    sample = dataset[0]

    img = sample["image"].unsqueeze(0)  # (1,3,512,512)
    mask_gt = sample["mask"].unsqueeze(0)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("Using device:", device)

    model = FullModel(pretrained_backbone=True).to(device)
    model.eval()

    with torch.no_grad():
        out = model(img.to(device), return_all=True)

    print("\n===== FULL MODEL OUTPUTS =====")
    print("mask_logits_up shape:", tuple(out["mask_logits_up"].shape))
    print("mask_logits_local shape:", tuple(out["mask_logits_local"].shape))
    print("boundary_logits_local shape:", tuple(out["boundary_logits_local"].shape))
    print("boundary_multi shapes:", {k: tuple(v.shape) for k, v in out["boundary_multi"].items()})
    print("final_feat shape:", tuple(out["final_feat"].shape))
    print("image_logit shape:", tuple(out["image_logit"].shape))
    print("c5_hat shape:", tuple(out["c5_hat"].shape))

    # quick sanity: compute mask probs and display mean
    probs = torch.sigmoid(out["mask_logits_up"])
    print("mask upsampled mean prob:", float(probs.mean().cpu().item()))

if __name__ == "__main__":
    main()
