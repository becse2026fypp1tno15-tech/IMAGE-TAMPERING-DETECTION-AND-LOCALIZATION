"""
Test segmentation + sampler-based contrastive losses end-to-end (paper-faithful).

This test:
 - runs a forward pass (backbone -> HAM -> decoder) on one CASIA2 sample
 - computes segmentation losses (mask + multi-scale boundary)
 - runs the boundary-guided sampler (Z candidates -> top-L hard positives/negatives)
 - computes contrastive loss using the sampled hard examples
"""

import os
import sys
import torch
import torch.nn.functional as F

# ---------------------------------------------------------------------
# bootstrap src imports
# ---------------------------------------------------------------------
HERE = os.path.dirname(__file__)
SRC_ROOT = os.path.abspath(os.path.join(HERE, ".."))
if SRC_ROOT not in sys.path:
    sys.path.insert(0, SRC_ROOT)

from data.casia2_dataset import CASIA2Dataset
from models.backbone import ResNet50Backbone
from models.hybrid_attention import HybridAttention
from models.decoder import SimpleDecoder

from losses.segmentation_losses import SegmentationLosses
from losses.boundary_sampler import sample_hard_examples
from losses.contrastive_loss import sampler_contrastive_loss   # IMPORTANT FIX


def main():
    # ---------------------------------------------------------
    # load sample from CASIA2
    # ---------------------------------------------------------
    casia_root = os.path.abspath(os.path.join(SRC_ROOT, "..", "data", "CASIA2"))
    dataset = CASIA2Dataset(root=casia_root, input_size=512, train=False)

    sample = dataset[0]
    img = sample["image"].unsqueeze(0)      # (1,3,512,512)
    mask_gt = sample["mask"].unsqueeze(0)   # (1,1,512,512)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("Using device:", device)

    # ---------------------------------------------------------
    # model components
    # ---------------------------------------------------------
    backbone = ResNet50Backbone(pretrained=True).to(device)
    ham = HybridAttention(in_channels=2048).to(device)
    decoder = SimpleDecoder().to(device)

    backbone.eval()
    ham.eval()
    decoder.eval()

    # ---------------------------------------------------------
    # forward pass (NO torch.no_grad)
    # ---------------------------------------------------------
    feats = backbone(img.to(device))
    c5 = feats["c5"]
    c5_hat = ham(c5)

    mask_logits_up, boundaries, final_feat = decoder(
        {
            "c2": feats["c2"],
            "c3": feats["c3"],
            "c4": feats["c4"]
        },
        c5_hat,
        input_size=(512, 512)
    )

    # ---------------------------------------------------------
    # Prepare multi-scale boundary GT
    # ---------------------------------------------------------
    b_full = sample["boundary"]
    if b_full.dim() == 2:
        b_full = b_full.unsqueeze(0).unsqueeze(0)
    elif b_full.dim() == 3:
        b_full = b_full.unsqueeze(0)

    b4 = F.interpolate(b_full.to(device), size=(32,32), mode="nearest")
    b3 = F.interpolate(b_full.to(device), size=(64,64), mode="nearest")
    b2 = F.interpolate(b_full.to(device), size=(128,128), mode="nearest")
    boundary_gt_dict = {"b4": b4, "b3": b3, "b2": b2}

    mask_gt = mask_gt.to(device)

    # ---------------------------------------------------------
    # segmentation losses (mask + boundary)
    # ---------------------------------------------------------
    seg_losses = SegmentationLosses(device=device)
    L_mask, L_boundary, L_total, debug = seg_losses(
        mask_logits_up, mask_gt, boundaries, boundary_gt_dict
    )

    print("\n===== SEGMENTATION LOSSES =====")
    print("L_mask:", float(L_mask.detach().cpu().item()))
    print("L_boundary:", float(L_boundary.detach().cpu().item()))
    print("Total segmentation loss:", float(L_total.detach().cpu().item()))
    print("Debug:", debug)

    # ---------------------------------------------------------
    # Sampler-based contrastive loss (paper-faithful)
    # ---------------------------------------------------------
    Z = 500       # number of candidates per region
    L = 256       # number of hard samples per region
    dilation = 3  # boundary dilation radius
    temperature = 0.1

    L_contrast, info = sampler_contrastive_loss(
        features=final_feat,
        mask_gt=mask_gt,
        sampler_fn=sample_hard_examples,
        Z=Z,
        L=L,
        dilation=dilation,
        temperature=temperature,
        device=device
    )

    print("\n===== CONTRASTIVE LOSS =====")
    print("Contrastive loss:", float(L_contrast.detach().cpu().item()))
    if isinstance(info, dict):
        print("Contrastive info:", info)


if __name__ == "__main__":
    main()
