# src/models/full_model.py
"""
FullModel wrapper that assembles Backbone -> HAM -> Decoder -> Heads.

Forward API:
    outputs = model(images)
where images is (B,3,H,W) preprocessed input (normalized).
Outputs is a dict with at least:
    - "mask_logits_up": (B,1,H_in,W_in) upsampled mask logits (decoder)
    - "mask_logits_local": (B,1,H2,W2) local mask logits (mask head)
    - "boundary_logits": dict {'b4':(B,1,32,32), 'b3':..., 'b2':...}
    - "final_feat": (B, C, Hf, Wf) final decoder feature (used by contrastive)
    - "image_logit": (B,1) image-level logit (image head)
    - "c5_hat": (B,2048,H/32,W/32) output of HAM (useful for debugging)
"""

import torch
import torch.nn as nn

from .backbone import ResNet50Backbone
from .hybrid_attention import HybridAttention
from .decoder import SimpleDecoder
from .heads import MaskHead, BoundaryHead, ImageLevelHead

class FullModel(nn.Module):
    def __init__(self, pretrained_backbone=True):
        super().__init__()
        # core modules
        self.backbone = ResNet50Backbone(pretrained=pretrained_backbone)
        self.ham = HybridAttention(in_channels=2048)
        self.decoder = SimpleDecoder()

        # heads operate on decoder final feature (and on c5_hat for image-level)
        # decoder.final_feat channels assumed 256 (as earlier)
        self.mask_head = MaskHead(in_channels=256)
        self.boundary_head = BoundaryHead(in_channels=256)
        # image-level head works on c5_hat (2048 channels)
        self.image_head = ImageLevelHead(in_channels=2048)

    def forward(self, x, return_all=False):
        """
        x: (B,3,H,W) preprocessed images (ImageNet normalized)
        return_all: if True, returns intermediate features too
        """
        feats = self.backbone(x)          # dict c2,c3,c4,c5
        c5 = feats['c5']
        c5_hat = self.ham(c5)             # HAM output

        # decoder consumes multi-scale features and c5_hat
        mask_logits_up, boundaries, final_feat = self.decoder(
            {"c2": feats['c2'], "c3": feats['c3'], "c4": feats['c4']},
            c5_hat,
            input_size=(x.shape[2], x.shape[3])
        )

        # Heads
        mask_logits_local = self.mask_head(final_feat)  # (B,1,H2,W2)
        boundary_logits_local = self.boundary_head(final_feat)  # (B,1,H2,W2)
        image_logit = self.image_head(c5_hat)  # (B,1)

        out = {
            "mask_logits_up": mask_logits_up,
            "mask_logits_local": mask_logits_local,
            "boundary_logits_local": boundary_logits_local,
            "boundary_multi": boundaries,   # the decoder-produced boundaries at b4,b3,b2
            "final_feat": final_feat,
            "image_logit": image_logit,
            "c5_hat": c5_hat
        }

        if return_all:
            out["backbone_feats"] = feats

        return out
