# src/models/heads.py
"""
Heads used by the network:
 - MaskHead: projects decoder feature -> single-channel mask logits.
 - BoundaryHead: projects feature -> single-channel boundary logits.
 - ImageLevelHead: global pooling + FC -> image-level tamper logit.

All heads are lightweight and intended to be attached to decoder/backbone outputs.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class MaskHead(nn.Module):
    """
    Mask head that converts decoder feature -> mask logits.
    - in_channels: channels in decoder final feature (e.g., 256)
    - mid_channels: internal channels
    """
    def __init__(self, in_channels, mid_channels=None):
        super().__init__()
        if mid_channels is None:
            mid_channels = max(32, in_channels // 2)

        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, mid_channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(mid_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(mid_channels, mid_channels//2, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(mid_channels//2),
            nn.ReLU(inplace=True),
            nn.Conv2d(mid_channels//2, 1, kernel_size=1)  # logits
        )

    def forward(self, feat):
        """
        feat: (B, C, H, W)
        returns:
          mask_logits: (B,1,H,W) - raw logits (no sigmoid)
        """
        return self.conv(feat)

    def upsample_to(self, mask_logits, size):
        """Upsample logits to target size (H,W)."""
        return F.interpolate(mask_logits, size=size, mode='bilinear', align_corners=False)


class BoundaryHead(nn.Module):
    """
    Boundary head to predict boundary logits at a given scale.
    """
    def __init__(self, in_channels, mid_channels=None):
        super().__init__()
        if mid_channels is None:
            mid_channels = max(16, in_channels // 4)
        self.net = nn.Sequential(
            nn.Conv2d(in_channels, mid_channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(mid_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(mid_channels, 1, kernel_size=1)
        )

    def forward(self, feat):
        """
        feat: (B,C,H,W)
        returns: boundary_logits (B,1,H,W)
        """
        return self.net(feat)


class ImageLevelHead(nn.Module):
    """
    Simple image-level tamper classifier:
    - Global average pooling -> FC -> 1 logit
    """
    def __init__(self, in_channels, hidden=128):
        super().__init__()
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(in_channels, hidden),
            nn.ReLU(inplace=True),
            nn.Linear(hidden, 1)  # logit
        )

    def forward(self, feat):
        """
        feat: (B,C,H,W)
        returns: logits (B,1)
        """
        B, C, H, W = feat.shape
        x = self.pool(feat).view(B, C)
        logit = self.fc(x).unsqueeze(1)  # shape (B,1)
        return logit
