# src/models/bam.py
"""
Boundary-Aware Attention Module (BAM)

Implements the procedure described in the base paper (practical variant):
 - Downsample encoder feature X_i to match decoder feature Xhat_{i+1} spatial size
 - Form H_tilde = concat(down_Xi, Xhat_{i+1})
 - Produce high-frequency map H_i = H_tilde - H_tilde * sigmoid(conv(avgpool(H_tilde)))
 - Predict boundary heatmap C_hat = conv(H_i) -> sigmoid
 - TopK selection on C_hat (per-sample)
 - Sample vectors from down_Xi and Xhat_{i+1} at TopK positions
 - Cross-attention: queries=encoder samples, keys/values=decoder samples
 - Scatter attended vectors back into a copy of down_Xi
 - Upsample updated encoder to original Xi size, upsample Xhat_{i+1} and fuse
 - Returns: X_hat_i (fused), boundary_map_upsampled (to Xi size)
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import math


class BAM(nn.Module):
    def __init__(self, enc_channels, dec_channels, topk=32, embed_dim=256):
        """
        enc_channels: channels of encoder feature X_i (e.g., c4=1024)
        dec_channels: channels of decoder input Xhat_{i+1} (e.g., c5_hat=2048)
        topk: number of boundary pixels to sample per image (K in paper)
        embed_dim: embedding dimension for attention computations
        """
        super().__init__()
        self.enc_channels = enc_channels
        self.dec_channels = dec_channels
        self.topk = topk
        self.embed_dim = embed_dim

        # for computing high-frequency mask: small conv on pooled features
        self.hf_pool_conv = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(enc_channels + dec_channels, enc_channels + dec_channels, kernel_size=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(enc_channels + dec_channels, enc_channels + dec_channels, kernel_size=1),
            nn.Sigmoid()
        )

        # boundary predictor
        self.boundary_pred = nn.Sequential(
            nn.Conv2d(enc_channels + dec_channels, enc_channels // 4, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(enc_channels // 4, 1, kernel_size=1),
            nn.Sigmoid()
        )

        # embeddings for attention (project to lower embed_dim)
        self.enc_proj = nn.Conv2d(enc_channels, embed_dim, kernel_size=1, bias=False)
        self.dec_proj = nn.Conv2d(dec_channels, embed_dim, kernel_size=1, bias=False)
        # project back to enc channels
        self.out_proj = nn.Conv2d(embed_dim, enc_channels, kernel_size=1, bias=False)

        # Fusion conv after concat(updated_enc, upsampled_decoder)
        self.fuse_conv = nn.Sequential(
            nn.Conv2d(enc_channels + dec_channels, enc_channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(enc_channels),
            nn.ReLU(inplace=True)
        )

    def forward(self, Xi, Xhat_next):
        """
        Xi: encoder feature at scale i: (B, C_e, H_e, W_e)
        Xhat_next: decoder feature from deeper scale: (B, C_d, H_d, W_d)
        Returns:
          X_hat_i: fused decoder feature at scale of Xi: (B, C_e, H_e, W_e)
          boundary_map_up: boundary map upsampled to (H_e, W_e)
        """
        B, Ce, He, We = Xi.shape
        _, Cd, Hd, Wd = Xhat_next.shape

        # 1) Downsample encoder to decoder spatial size
        down_Xi = F.interpolate(Xi, size=(Hd, Wd), mode="bilinear", align_corners=False)  # (B,Ce,Hd,Wd)

        # 2) H_tilde = concat(down_Xi, Xhat_next)
        Htil = torch.cat([down_Xi, Xhat_next], dim=1)  # (B, Ce+Cd, Hd, Wd)

        # 3) high-frequency extraction: Hi = Htil - Htil * sigmoid(conv(avgpool(Htil)))
        hf_weight = self.hf_pool_conv(Htil)  # (B, Ce+Cd, 1, 1)
        Hi = Htil - Htil * hf_weight         # (B, Ce+Cd, Hd, Wd)

        # 4) boundary prediction on Hi
        C_hat = self.boundary_pred(Hi)       # (B,1,Hd,Wd) in 0..1

        # 5) Top-K selection per image
        Xhat_list = []
        updated_down_list = []
        for b in range(B):
            # flatten boundary map (Hd*Wd)
            ch = C_hat[b:b+1, 0]  # (1,Hd,Wd)
            flat = ch.view(-1)    # (N,)
            K = min(self.topk, flat.numel())
            if K <= 0:
                # nothing to do
                topk_idx = torch.zeros(0, dtype=torch.long, device=Xi.device)
            else:
                _, topk_idx = torch.topk(flat, k=K, largest=True, sorted=False)  # indices in flattened map

            # prepare sample vectors from down_Xi and Xhat_next
            # project to embed_dim
            enc_proj = self.enc_proj(down_Xi[b:b+1])  # (1, embed, Hd, Wd)
            dec_proj = self.dec_proj(Xhat_next[b:b+1])  # (1, embed, Hd, Wd)

            N = Hd * Wd
            if topk_idx.numel() == 0:
                # no selected pixels — skip attention and leave down_Xi as-is
                updated_down = down_Xi[b:b+1]
            else:
                # flatten spatial dims to (N, embed)
                enc_flat = enc_proj.view(1, self.embed_dim, N).permute(0,2,1).squeeze(0)  # (N, embed)
                dec_flat = dec_proj.view(1, self.embed_dim, N).permute(0,2,1).squeeze(0)  # (N, embed)

                # pick K sampled vectors
                enc_samples = enc_flat[topk_idx, :]  # (K, embed)
                dec_samples = dec_flat[topk_idx, :]  # (K, embed)

                # attention: enc_samples as queries, dec_samples as keys/values
                # compute similarity QK^T
                # (K,embed) @ (embed,K) -> (K,K)
                q = enc_samples       # (K, E)
                k = dec_samples       # (K, E)
                v = dec_samples       # (K, E) (we use dec_samples as values)

                # scaled dot-product attention across the K points (local pairwise)
                scale = math.sqrt(self.embed_dim)
                attn_scores = torch.matmul(q, k.transpose(0,1)) / scale   # (K,K)
                attn_weights = F.softmax(attn_scores, dim=-1)             # (K,K)

                attended = torch.matmul(attn_weights, v)   # (K, E)

                # now we need to write back these attended vectors into the enc feature map
                # create updated enc flattened and replace topk positions
                enc_flat_clone = enc_flat.clone()
                enc_flat_clone[topk_idx, :] = attended  # (N, E)

                # reshape back to (1, E, Hd, Wd)
                enc_updated_proj = enc_flat_clone.unsqueeze(0).permute(0,2,1).contiguous().view(1, self.embed_dim, Hd, Wd)

                # project back to encoder channels
                updated_down = self.out_proj(enc_updated_proj)  # (1, Ce, Hd, Wd)

            updated_down_list.append(updated_down)

        # stack updated_downs
        updated_down = torch.cat(updated_down_list, dim=0)  # (B, Ce, Hd, Wd)

        # 6) Upsample updated_down back to encoder spatial size (He,We)
        updated_up = F.interpolate(updated_down, size=(He, We), mode="bilinear", align_corners=False)  # (B,Ce,He,We)

        # 7) Upsample Xhat_next to encoder spatial size and fuse
        up_Xhat = F.interpolate(Xhat_next, size=(He, We), mode="bilinear", align_corners=False)  # (B,Cd,He,We)

        fused = torch.cat([updated_up, up_Xhat], dim=1)  # (B, Ce+Cd, He, We)
        X_hat_i = self.fuse_conv(fused)  # (B, Ce, He, We)

        # also return upsampled boundary map for supervision
        boundary_up = F.interpolate(C_hat, size=(He, We), mode="bilinear", align_corners=False)  # (B,1,He,We)

        return X_hat_i, boundary_up
