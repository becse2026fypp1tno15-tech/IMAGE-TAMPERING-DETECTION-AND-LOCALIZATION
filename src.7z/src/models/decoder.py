# src/models/decoder.py
"""
Decoder that uses BAM at each scale to progressively reconstruct a mask.
Follows the base paper flow:
  c5 -> HAM -> BAM(c4) -> BAM(c3) -> BAM(c2) -> mask head (upsampled to input)
Returns final mask logits and multi-scale boundary preds.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F

from .bam import BAM

class SimpleDecoder(nn.Module):
    def __init__(self, channels_c2=256, channels_c3=512, channels_c4=1024, channels_c5=2048,
                 topk=32, embed_dim=256):
        super().__init__()
        # We'll create a BAM for each decoder step:
        # BAM_i: uses enc channels (c_i) and decoder channels (current)
        self.bam_c4 = BAM(enc_channels=channels_c4, dec_channels=channels_c5, topk=topk, embed_dim=embed_dim)
        self.bam_c3 = BAM(enc_channels=channels_c3, dec_channels=channels_c4, topk=topk, embed_dim=embed_dim)
        self.bam_c2 = BAM(enc_channels=channels_c2, dec_channels=channels_c3, topk=topk, embed_dim=embed_dim)

        # After each BAM produce a refined decoder feature with same channels as encoder (Ce)
        # We'll optionally reduce channels of c5_hat to match dec channels for the first BAM usage if needed.
        # Provide small smoothing convs after each stage
        self.smooth4 = nn.Sequential(
            nn.Conv2d(channels_c4, channels_c4, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(channels_c4),
            nn.ReLU(inplace=True)
        )
        self.smooth3 = nn.Sequential(
            nn.Conv2d(channels_c3, channels_c3, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(channels_c3),
            nn.ReLU(inplace=True)
        )
        self.smooth2 = nn.Sequential(
            nn.Conv2d(channels_c2, channels_c2, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(channels_c2),
            nn.ReLU(inplace=True)
        )

        # Final mask head: project channels -> 1 and upsample to input size later
        self.mask_head = nn.Sequential(
            nn.Conv2d(channels_c2, channels_c2//2, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(channels_c2//2),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels_c2//2, 1, kernel_size=1)
        )

    def forward(self, feats, c5_hat, input_size=None):
        """
        feats: dict with keys c2,c3,c4 (encoder features)
        c5_hat: enhanced deepest feature (B, C5, H5, W5)
        input_size: tuple (H_in, W_in) e.g., (512,512) for final upsampling
        Returns:
          mask_logits_up: (B,1,H_in,W_in)
          boundaries: dict of multi-scale boundary maps {'b4':..., 'b3':..., 'b2':...} (spatial at c4/c3/c2)
          decoder_feat: final decoder feature at c2 spatial
        """
        c2 = feats['c2']
        c3 = feats['c3']
        c4 = feats['c4']

        # Stage 1: BAM with c4
        X_hat_4, b4 = self.bam_c4(c4, c5_hat)   # X_hat_4: (B, C4, H4, W4), b4: (B,1,H4,W4)
        X_hat_4 = self.smooth4(X_hat_4)

        # Stage 2: BAM with c3 (use X_hat_4 as decoder input)
        X_hat_3, b3 = self.bam_c3(c3, X_hat_4)  # X_hat_3: (B, C3, H3, W3)
        X_hat_3 = self.smooth3(X_hat_3)

        # Stage 3: BAM with c2
        X_hat_2, b2 = self.bam_c2(c2, X_hat_3)  # X_hat_2: (B, C2, H2, W2)
        X_hat_2 = self.smooth2(X_hat_2)

        # Final mask head: produce logits at c2 spatial, then upsample to input
        mask_logits = self.mask_head(X_hat_2)  # (B,1,H2,W2)

        if input_size is not None:
            mask_logits_up = F.interpolate(mask_logits, size=input_size, mode='bilinear', align_corners=False)
        else:
            mask_logits_up = mask_logits

        boundaries = {'b4': b4, 'b3': b3, 'b2': b2}

        return mask_logits_up, boundaries, X_hat_2
