# src/models/backbone.py
"""
ResNet-50 backbone that returns multi-scale feature maps.
C2 = layer1 output (1/4 resolution)
C3 = layer2 output (1/8 resolution)
C4 = layer3 output (1/16 resolution)
C5 = layer4 output (1/32 resolution)

This matches the base paper feature extraction.
"""

import torch
import torch.nn as nn
import torchvision.models as models


class ResNet50Backbone(nn.Module):
    def __init__(self, pretrained=True):
        super().__init__()
        # Load torchvision resnet50
        resnet = models.resnet50(pretrained=pretrained)

        # Keep the initial layers (conv1, bn1, relu, maxpool)
        self.stem = nn.Sequential(
            resnet.conv1,  # stride=2
            resnet.bn1,
            resnet.relu,
            resnet.maxpool  # reduces to 1/4
        )

        # ResNet blocks
        self.layer1 = resnet.layer1  # C2
        self.layer2 = resnet.layer2  # C3
        self.layer3 = resnet.layer3  # C4
        self.layer4 = resnet.layer4  # C5

        # freeze_bn option could be added if needed; for now we leave layers trainable
        # simple identity for clarity
        self._out_channels = {
            "c2": 256,   # layer1 output channels for resnet50
            "c3": 512,   # layer2
            "c4": 1024,  # layer3
            "c5": 2048   # layer4
        }

    def forward(self, x):
        """
        x: (B,3,H,W) expected 512x512 input (but any multiple of 32 works)
        returns dict with keys: c2, c3, c4, c5
        """
        # stem -> reduces to 1/4 resolution
        x = self.stem(x)
        c2 = self.layer1(x)  # 1/4
        c3 = self.layer2(c2) # 1/8
        c4 = self.layer3(c3) # 1/16
        c5 = self.layer4(c4) # 1/32

        return {"c2": c2, "c3": c3, "c4": c4, "c5": c5}

    def out_channels(self):
        return self._out_channels
