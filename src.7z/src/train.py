"""
train.py (FP32 SAFE — BASE PAPER FAITHFUL)

Paper-faithful training loop for:
"Attentive and Contrastive Image Manipulation Localization with Boundary Guidance"

NO AMP
NO autocast
NO GradScaler
NaN-protected
"""

import os
import sys
import time
import json
import random
import argparse
from collections import defaultdict

import numpy as np
from tqdm import tqdm

import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader, random_split

# -------------------------------------------------------------------------
HERE = os.path.dirname(__file__)
if HERE not in sys.path:
    sys.path.insert(0, HERE)

from data.casia2_dataset import CASIA2Dataset
from models.full_model import FullModel
from losses.segmentation_losses import SegmentationLosses
from losses.contrastive_loss import sampler_contrastive_loss
from losses.boundary_sampler import sample_hard_examples

# -------------------------
# metrics
# -------------------------
def compute_binary_metrics(pred_mask_probs, gt_mask, thresh=0.5):
    pred_bin = (pred_mask_probs >= thresh).astype(np.uint8)
    gt = (gt_mask >= 0.5).astype(np.uint8)
    tp = (pred_bin & gt).sum()
    fp = (pred_bin & (1 - gt)).sum()
    fn = ((1 - pred_bin) & gt).sum()
    return tp, fp, fn


def compute_iou_f1_from_counters(tp, fp, fn, eps=1e-8):
    precision = tp / (tp + fp + eps)
    recall = tp / (tp + fn + eps)
    f1 = 2 * precision * recall / (precision + recall + eps)
    iou = tp / (tp + fp + fn + eps)
    return float(iou), float(f1), float(precision), float(recall)

# -------------------------
# validation
# -------------------------
def validate(model, dataloader, device):
    model.eval()
    total_tp = total_fp = total_fn = 0

    with torch.no_grad():
        for batch in tqdm(dataloader, desc="Val", leave=False):
            images = batch['image'].to(device)
            masks = batch['mask'].to(device)

            out = model(images, return_all=True)
            probs = torch.sigmoid(out['mask_logits_up']).cpu().numpy()
            gt = masks.squeeze(1).cpu().numpy()

            for i in range(probs.shape[0]):
                tp, fp, fn = compute_binary_metrics(probs[i, 0], gt[i])
                total_tp += tp
                total_fp += fp
                total_fn += fn

    iou, f1, precision, recall = compute_iou_f1_from_counters(
        total_tp, total_fp, total_fn
    )

    return {"iou": iou, "f1": f1, "precision": precision, "recall": recall}

# -------------------------
# training one epoch (FP32)
# -------------------------
def train_one_epoch(epoch, model, dataloader, optimizer, seg_loss_fn, device, cfg):
    model.train()
    running = defaultdict(float)

    pbar = tqdm(dataloader, desc=f"Epoch {epoch}")

    for batch in pbar:
        images = batch['image'].to(device)
        masks = batch['mask'].to(device)

        boundaries_full = batch.get('boundary', None)
        if boundaries_full is not None:
            if boundaries_full.dim() == 3:
                boundaries_full = boundaries_full.unsqueeze(1)
            boundaries_full = boundaries_full.to(device)

        optimizer.zero_grad()

        out = model(images, return_all=True)

        boundary_gt_dict = {
            'b4': F.interpolate(boundaries_full, (32, 32), mode='nearest') if boundaries_full is not None else None,
            'b3': F.interpolate(boundaries_full, (64, 64), mode='nearest') if boundaries_full is not None else None,
            'b2': F.interpolate(boundaries_full, (128, 128), mode='nearest') if boundaries_full is not None else None
        }

        L_mask, L_boundary, _, _ = seg_loss_fn(
            out['mask_logits_up'], masks, out['boundary_multi'], boundary_gt_dict
        )

        L_contrast, _ = sampler_contrastive_loss(
            features=out['final_feat'],
            mask_gt=masks,
            sampler_fn=sample_hard_examples,
            Z=cfg.Z, L=cfg.L,
            dilation=cfg.dilation,
            temperature=cfg.temperature,
            device=device
        )

        img_labels = torch.ones_like(out['image_logit'], device=device)
        L_img = F.binary_cross_entropy_with_logits(out['image_logit'], img_labels)

        L_total = (L_mask + L_boundary) + cfg.lambda_c * L_contrast + cfg.lambda_i * L_img

        # ✅ NaN protection
        if not torch.isfinite(L_total):
            print("❌ NaN detected — batch skipped")
            continue

        L_total.backward()
        optimizer.step()

        running['L_total'] += L_total.item()

        pbar.set_postfix({"L": f"{running['L_total']/(len(pbar)+1):.4f}"})

    avg = {k: v / len(dataloader) for k, v in running.items()}
    return avg

# -------------------------
# args
# -------------------------
def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--data-root", type=str, required=True)
    p.add_argument("--save-dir", type=str, default="../checkpoints")
    p.add_argument("--epochs", type=int, default=50)
    p.add_argument("--batch-size", type=int, default=4)
    p.add_argument("--lr", type=float, default=1e-4)
    p.add_argument("--weight-decay", type=float, default=1e-5)
    p.add_argument("--num-workers", type=int, default=4)
    p.add_argument("--val-split", type=float, default=0.1)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--Z", type=int, default=500)
    p.add_argument("--L", type=int, default=256)
    p.add_argument("--dilation", type=int, default=3)
    p.add_argument("--temperature", type=float, default=0.1)
    p.add_argument("--lambda-c", type=float, default=1.0, dest="lambda_c")
    p.add_argument("--lambda-i", type=float, default=0.1, dest="lambda_i")
    return p.parse_args()

# -------------------------
def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

# -------------------------
# main
# -------------------------
def main():
    cfg = parse_args()
    set_seed(cfg.seed)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    os.makedirs(cfg.save_dir, exist_ok=True)

    dataset = CASIA2Dataset(cfg.data_root, input_size=512, train=True)
    val_n = int(len(dataset) * cfg.val_split)
    train_n = len(dataset) - val_n

    train_set, val_set = random_split(dataset, [train_n, val_n])

    train_loader = DataLoader(train_set, batch_size=cfg.batch_size, shuffle=True, num_workers=cfg.num_workers)
    val_loader = DataLoader(val_set, batch_size=1, shuffle=False)

    model = FullModel(pretrained_backbone=True).to(device)
    seg_loss_fn = SegmentationLosses(device=device)

    optimizer = torch.optim.Adam(model.parameters(), lr=cfg.lr, weight_decay=cfg.weight_decay)
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, 20, 0.1)

    best_val_f1 = 0.0
    train_log = []

    for epoch in range(cfg.epochs):
        avg_train = train_one_epoch(epoch, model, train_loader, optimizer, seg_loss_fn, device, cfg)
        scheduler.step()

        val_metrics = validate(model, val_loader, device)

        print(f"Epoch {epoch} | Train {avg_train['L_total']:.4f} | Val F1 {val_metrics['f1']:.4f}")

        ckpt = {
            'epoch': epoch,
            'model_state': model.state_dict(),
            'optim_state': optimizer.state_dict(),
            'best_val_f1': best_val_f1
        }

        torch.save(ckpt, os.path.join(cfg.save_dir, f"ckpt_epoch_{epoch}.pth"))

        if val_metrics['f1'] > best_val_f1:
            best_val_f1 = val_metrics['f1']
            ckpt['best_val_f1'] = best_val_f1
            torch.save(ckpt, os.path.join(cfg.save_dir, "best.pth"))
            print("✅ New best model saved")

    print("Training finished. Best F1:", best_val_f1)

if __name__ == "__main__":
    main()
