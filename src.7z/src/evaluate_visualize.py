# visualize_small.py
"""
Save a small subset of validation visualizations (disk-friendly).

Usage (from src/):
    python visualize_small.py --data-root ../data/CASIA2 --ckpt ../checkpoints/best.pth --n 50 --seed 42

Output:
    checkpoints/eval_out/vis_small/*.png
    checkpoints/eval_out/vis_small/summary.json
"""
import os
import argparse
import json
import random

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader

# make sure repo root is in path when called from src/
import sys
HERE = os.path.dirname(__file__)
if HERE not in sys.path:
    sys.path.insert(0, HERE)

from data.casia2_dataset import CASIA2Dataset
from models.full_model import FullModel
from PIL import Image
import matplotlib.pyplot as plt

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--data-root", required=True)
    p.add_argument("--ckpt", default="../checkpoints/best.pth")
    p.add_argument("--save-dir", default="../checkpoints/eval_out/vis_small")
    p.add_argument("--n", type=int, default=50, help="Number of images to visualize")
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--device", type=str, default="cuda")
    p.add_argument("--thumb-size", type=int, default=256, help="output short edge size in pixels")
    return p.parse_args()

def ensure_val_split(full_dataset, val_fraction=0.1, seed=42):
    N = len(full_dataset)
    val_n = int(N * val_fraction)
    train_n = N - val_n
    # recreate same split as training (deterministic)
    train_set, val_set = torch.utils.data.random_split(
        full_dataset, [train_n, val_n],
        generator=torch.Generator().manual_seed(seed)
    )
    return val_set

def norm_to_uint8(x):
    x = np.clip(x, 0.0, 1.0)
    x = (x * 255).astype(np.uint8)
    return x

def make_vis_grid(img, gt_mask, prob_map, pred_mask, out_path, thumb_size=256):
    """
    img: numpy (H,W,3) in [0,1]
    gt_mask, prob_map, pred_mask: (H,W) arrays
    """
    H, W = img.shape[:2]
    # resize to keep short edge = thumb_size
    short = min(H, W)
    scale = thumb_size / short
    newH = max(1, int(round(H * scale)))
    newW = max(1, int(round(W * scale)))

    img_pil = Image.fromarray(norm_to_uint8(img))
    img_pil = img_pil.resize((newW, newH), Image.BILINEAR)

    gt_pil = Image.fromarray((gt_mask * 255).astype(np.uint8)).resize((newW, newH), Image.NEAREST).convert("L")
    prob_vis = (prob_map * 255).astype(np.uint8)
    prob_pil = Image.fromarray(prob_vis).resize((newW, newH), Image.BILINEAR).convert("L")
    pred_pil = Image.fromarray((pred_mask * 255).astype(np.uint8)).resize((newW, newH), Image.NEAREST).convert("L")

    # create a horizontal grid: original | GT | prob (viridis) | pred
    fig_w = newW * 4
    fig_h = newH
    fig = plt.figure(figsize=(fig_w / 100, fig_h / 100), dpi=100)
    ax = fig.add_subplot(1, 4, 1); ax.imshow(img_pil); ax.set_title("Image"); ax.axis("off")
    ax = fig.add_subplot(1, 4, 2); ax.imshow(gt_pil, cmap="gray"); ax.set_title("GT"); ax.axis("off")
    ax = fig.add_subplot(1, 4, 3); ax.imshow(prob_pil, cmap="viridis"); ax.set_title("Prob"); ax.axis("off")
    ax = fig.add_subplot(1, 4, 4); ax.imshow(pred_pil, cmap="gray"); ax.set_title("Pred"); ax.axis("off")
    plt.tight_layout(pad=0.5)
    fig.savefig(out_path, bbox_inches="tight", pad_inches=0.1)
    plt.close(fig)

def main():
    args = parse_args()
    device = torch.device(args.device if torch.cuda.is_available() and args.device == "cuda" else "cpu")
    print("Device:", device)
    os.makedirs(args.save_dir, exist_ok=True)

    # load full dataset then take val split (same as training)
    full_dataset = CASIA2Dataset(root=args.data_root, input_size=512, train=True)
    val_set = ensure_val_split(full_dataset, val_fraction=0.1, seed=args.seed)
    n_val = len(val_set)
    print(f"Validation split size: {n_val}")

    # pick indices for a small subset
    rng = random.Random(args.seed)
    all_indices = list(range(n_val))
    rng.shuffle(all_indices)
    subset_indices = all_indices[: min(args.n, n_val)]
    print(f"Visualizing {len(subset_indices)} images (indices in val split sample): {subset_indices[:10]}...")

    # loader for selected samples
    # val_set is a Subset, we will map chosen indices to actual dataset indices
    chosen = [val_set.indices[i] for i in subset_indices]
    subset = torch.utils.data.Subset(full_dataset, chosen)
    loader = DataLoader(subset, batch_size=1, shuffle=False, num_workers=2)

    # model
    model = FullModel(pretrained_backbone=True).to(device)
    ckpt = torch.load(args.ckpt, map_location=device)
    if isinstance(ckpt, dict) and "model_state" in ckpt:
        model.load_state_dict(ckpt["model_state"])
    else:
        model.load_state_dict(ckpt)
    model.eval()
    print("Loaded checkpoint:", args.ckpt)

    saved = []
    with torch.no_grad():
        for i, sample in enumerate(loader):
            img = sample["image"].to(device)            # (1,3,H,W)
            gt = sample["mask"].squeeze(0).squeeze(0).cpu().numpy()  # (H,W), {0,1}

            out = model(img, return_all=True)
            prob = torch.sigmoid(out["mask_logits_up"]).squeeze(0).squeeze(0).cpu().numpy()
            # choose best threshold as 0.5 for quick visualization OR use mean_best_thresh if you saved it
            thresh = 0.5
            pred = (prob >= thresh).astype(np.uint8)

            # convert input image back to uint8 RGB (assuming dataset returns normalized floats 0..1)
            # If your dataset returns other normalization adjust here.
            # We'll try to recover original by sample["orig_image"] if exists, else use image tensor
            if "orig_image" in sample:
                img_np = sample["orig_image"].squeeze(0).permute(1,2,0).cpu().numpy()
            else:
                # image is normalized 0..1 or [-1,1]; attempt to rescale
                img_t = sample["image"].squeeze(0).permute(1,2,0).cpu().numpy()
                # clamp to 0..1
                img_np = np.clip(img_t, 0.0, 1.0)

            out_fn = os.path.join(args.save_dir, f"vis_{i:04d}.png")
            make_vis_grid(img_np, gt, prob, pred, out_fn, thumb_size=args.thumb_size)
            saved.append(out_fn)

    # write summary
    summary = {"n_saved": len(saved), "files": saved}
    with open(os.path.join(args.save_dir, "summary.json"), "w") as f:
        json.dump(summary, f, indent=2)

    print("Saved visuals to:", args.save_dir)
    print("Done.")

if __name__ == "__main__":
    main()
