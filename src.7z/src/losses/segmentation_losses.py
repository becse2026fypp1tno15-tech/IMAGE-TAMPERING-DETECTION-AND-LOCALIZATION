# src/losses/segmentation_losses.py
import torch
import torch.nn as nn
import torch.nn.functional as F


class DiceLoss(nn.Module):
    """Soft Dice loss for binary masks."""
    def __init__(self, eps: float = 1e-6):
        super().__init__()
        self.eps = eps

    def forward(self, logits: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        """
        logits: (B,1,H,W) raw logits
        target: (B,1,H,W) binary {0,1}
        """
        # work in float32 for stability
        logits = logits.float()
        target = target.float()

        probs = torch.sigmoid(logits)
        num = 2.0 * (probs * target).sum(dim=(1, 2, 3))
        den = probs.sum(dim=(1, 2, 3)) + target.sum(dim=(1, 2, 3)) + self.eps
        dice = num / den
        loss = 1.0 - dice
        return loss.mean()


class SegmentationLosses:
    """
    Wrapper for segmentation + boundary losses.

    Usage:
        loss_fn = SegmentationLosses()
        L_mask, L_boundary, L_total, debug = loss_fn(
            mask_logits, mask_gt, boundaries_pred, boundary_gt_dict
        )
    """
    def __init__(self, weight_bce: float = 1.0, weight_dice: float = 1.0, device=None):
        # Mask segmentation: logits + BCEWithLogits (AMP-safe)
        self.bce = nn.BCEWithLogitsLoss()
        self.dice = DiceLoss()
        self.w_bce = weight_bce
        self.w_dice = weight_dice
        self.device = device

    # ------------------ mask (tampered area) ------------------ #
    def mask_loss(self, mask_logits: torch.Tensor, mask_gt: torch.Tensor):
        """
        mask_logits: (B,1,H,W) logits
        mask_gt:     (B,1,H,W) binary {0,1}
        """
        mask_logits = mask_logits.float()
        mask_gt = mask_gt.float()

        bce = self.bce(mask_logits, mask_gt)
        d = self.dice(mask_logits, mask_gt)
        return self.w_bce * bce + self.w_dice * d, bce.detach(), d.detach()

    # ------------------ boundary maps (multi-scale) ----------- #
    def boundary_loss(self, boundaries_pred, boundary_gt_dict):
        """
        boundaries_pred: dict {'b4': (B,1,32,32), 'b3': (B,1,64,64), 'b2': (B,1,128,128)}
            These are logits or probabilities from the decoder.
        boundary_gt_dict: dict with same keys containing GT boundaries at those sizes.

        Returns: (total_loss, per_scale_losses_dict)
        """
        total = 0.0
        losses = {}

        for k, pred in boundaries_pred.items():
            if k not in boundary_gt_dict:
                continue

            gt = boundary_gt_dict[k]
            if gt is None:
                continue

            # move to same device & cast
            pred = pred.to(pred.device).float()
            gt = gt.to(pred.device).float()

            # ensure same spatial size
            if gt.shape != pred.shape:
                gt = F.interpolate(gt, size=pred.shape[2:], mode="nearest")

            # 1) convert logits -> probabilities (idempotent if already probs)
            pred_prob = torch.sigmoid(pred)

            # 2) clean numerics: clamp + handle NaN/Inf so BCE never asserts
            pred_prob = torch.clamp(pred_prob, 0.0, 1.0)
            pred_prob = torch.nan_to_num(pred_prob, nan=0.5, posinf=1.0, neginf=0.0)

            gt = torch.clamp(gt, 0.0, 1.0)
            gt = torch.nan_to_num(gt, nan=0.0, posinf=1.0, neginf=0.0)

            # 3) BCE on probabilities in [0,1]
            l = F.binary_cross_entropy(pred_prob, gt)

            losses[k] = l.detach()
            total = total + l

        return total, losses

    # ------------------ combined ------------------------------ #
    def __call__(self, mask_logits, mask_gt, boundaries_pred, boundary_gt_dict):
        """
        Compute mask + boundary losses and return:
            (L_mask, L_boundary, total_loss, debug_info)

        debug_info contains:
          - mask_bce
          - mask_dice
          - per-scale boundary BCE losses
        """
        # mask loss (with logits)
        L_mask, bce_val, dice_val = self.mask_loss(
            mask_logits,
            mask_gt.to(mask_logits.device)
        )

        # boundary loss (on cleaned probability maps)
        L_boundary, boundary_losses = self.boundary_loss(
            boundaries_pred,
            boundary_gt_dict
        )

        total = L_mask + L_boundary

        # NOTE: the CUDA assert actually happens *inside* BCE;
        # accessing .item() just syncs and reports it. With the
        # cleaned inputs above, that assert should no longer appear.
        debug = {
            "mask_bce": float(bce_val.cpu().item()),
            "mask_dice": float(dice_val.cpu().item()),
            "boundary_losses": {k: float(v.cpu().item()) for k, v in boundary_losses.items()}
        }
        return L_mask, L_boundary, total, debug
