# src/losses/boundary_sampler.py
"""
Boundary-guided sampler + hard mining

Implements:
 - dilation-based exterior boundary extraction
 - sampling Z points from tampered region and exterior region
 - computing prototypes and hard-mining:
     * hard positives: pos samples farthest from pos-prototype
     * hard negatives: neg samples closest (most similar) to pos-prototype
 - returns selected positive and negative feature vectors and their coordinates

API:

sampled = sample_hard_examples(
    features,        # (B, C, Hf, Wf) feature map (torch.Tensor)
    mask_gt,         # (B, 1, Hin, Win) binary ground truth mask (torch.Tensor)
    Z=500,           # number of candidate samples per region (tampered & exterior)
    L=256,           # number of hard samples to keep per region (<= Z)
    dilation=3,      # dilation radius for exterior region (in feature-space pixels after resize)
    device=None
)

Returns dict with keys (for each batch element):
 {
   'pos_feats': Tensor (L, C),
   'neg_feats': Tensor (L, C),
   'pos_idx': Tensor (L,) indices in flattened Hf*Wf,
   'neg_idx': Tensor (L,)
 }
If insufficient samples exist, sizes are reduced accordingly.
"""

import torch
import torch.nn.functional as F
import math


def dilate_mask(mask, dilation):
    """
    Dilate a binary mask using max_pool2d.
    mask: (1, 1, H, W) or (B,1,H,W) with values in {0,1}
    dilation: integer radius (d) -> kernel = 2*d + 1
    returns dilated_mask (same shape)
    """
    if dilation <= 0:
        return mask
    k = 2 * dilation + 1
    # max_pool2d acts like dilation for binary masks
    pad = dilation
    return F.max_pool2d(mask, kernel_size=k, stride=1, padding=pad)


def sample_hard_examples(features, mask_gt, Z=500, L=256, dilation=3, device=None):
    """
    features: (B, C, Hf, Wf)
    mask_gt: (B, 1, Hin, Win) binary {0,1}
    Returns: list of per-batch dicts with selected pos/neg features and indices
    """
    device = features.device if device is None else device
    B, C, Hf, Wf = features.shape

    # Resize mask_gt to feature spatial with nearest (preserve binary)
    mask_resized = F.interpolate(mask_gt.to(device), size=(Hf, Wf), mode='nearest')  # (B,1,Hf,Wf)
    mask_resized = (mask_resized > 0.5).float()

    results = []

    for b in range(B):
        mask_b = mask_resized[b:b+1]             # (1,1,Hf,Wf)
        feat_b = features[b:b+1]                 # (1,C,Hf,Wf)
        N = Hf * Wf

        # flatten feature vectors [N, C]
        feat_flat = feat_b.view(1, C, N).permute(0, 2, 1).squeeze(0)  # (N, C)
        mask_flat = mask_b.view(-1)  # (N,)

        # 1) build exterior boundary: dilate(mask) - mask
        dil = dilate_mask(mask_b, dilation).view(-1)
        exterior = ((dil - mask_flat) > 0.5).float()  # (N,) 1 for exterior region

        # find indices
        pos_idx_all = torch.nonzero(mask_flat > 0.5).squeeze(1)      # tampered pixels
        ext_idx_all = torch.nonzero(exterior > 0.5).squeeze(1)      # exterior pixels

        # If both empty, return empty placeholders
        if pos_idx_all.numel() == 0:
            # no tampered pixels in this sample (unlikely for CASIA Tp, but safe)
            results.append({
                'pos_feats': torch.zeros((0, C), device=device),
                'neg_feats': torch.zeros((0, C), device=device),
                'pos_idx': torch.zeros((0,), dtype=torch.long, device=device),
                'neg_idx': torch.zeros((0,), dtype=torch.long, device=device)
            })
            continue

        # 2) sample up to Z candidates from pos and exterior
        def sample_indices(idx_all, K):
            if idx_all.numel() == 0:
                return idx_all.new_empty((0,), dtype=torch.long)
            if idx_all.numel() <= K:
                return idx_all
            perm = torch.randperm(idx_all.numel(), device=device)[:K]
            return idx_all[perm]

        pos_cand = sample_indices(pos_idx_all, Z)   # (<=Z,)
        neg_cand = sample_indices(ext_idx_all, Z)   # (<=Z,)

        # If no exterior candidates found, fall back to sampling from non-pos (whole background)
        if neg_cand.numel() == 0:
            bg_idx_all = torch.nonzero(mask_flat <= 0.5).squeeze(1)
            neg_cand = sample_indices(bg_idx_all, Z)

        # Extract feature vectors for candidates
        pos_feats_cand = feat_flat[pos_cand] if pos_cand.numel() > 0 else feat_flat.new_empty((0, C))
        neg_feats_cand = feat_flat[neg_cand] if neg_cand.numel() > 0 else feat_flat.new_empty((0, C))

        # 3) compute positive prototype and select hard positives
        # if pos_feats_cand empty -> skip
        if pos_feats_cand.numel() == 0:
            selected_pos_feats = feat_flat.new_empty((0, C))
            selected_pos_idx = pos_cand.new_empty((0,), dtype=torch.long)
        else:
            p_pos = pos_feats_cand.mean(dim=0, keepdim=True)  # (1, C)
            # compute cosine similarity of pos feats to prototype
            pos_norm = F.normalize(pos_feats_cand, dim=1)
            p_pos_norm = F.normalize(p_pos, dim=1)
            sims_pos = (pos_norm @ p_pos_norm.t()).squeeze(1)  # (P,)
            # hard positives = those *farthest* from prototype -> smallest similarity
            Kpos = min(L, pos_feats_cand.shape[0])
            if Kpos == pos_feats_cand.shape[0]:
                sel_pos_idx_local = torch.arange(pos_feats_cand.shape[0], device=device)
            else:
                # select indices of smallest similarities
                _, order = torch.topk(-sims_pos, k=Kpos, largest=True)
                sel_pos_idx_local = order
            selected_pos_feats = pos_feats_cand[sel_pos_idx_local]  # (Kpos, C)
            selected_pos_idx = pos_cand[sel_pos_idx_local]           # indices in flattened map

        # 4) compute hard negatives: negatives most similar to positive prototype (hardest)
        if neg_feats_cand.numel() == 0:
            selected_neg_feats = feat_flat.new_empty((0, C))
            selected_neg_idx = neg_cand.new_empty((0,), dtype=torch.long)
        else:
            # use previously computed p_pos (if pos existed) else compute pos prototype from all pos
            if pos_feats_cand.numel() == 0:
                # fallback: use random negs
                Kneg = min(L, neg_feats_cand.shape[0])
                if Kneg == neg_feats_cand.shape[0]:
                    sel_neg_idx_local = torch.arange(neg_feats_cand.shape[0], device=device)
                else:
                    perm = torch.randperm(neg_feats_cand.shape[0], device=device)[:Kneg]
                    sel_neg_idx_local = perm
                selected_neg_feats = neg_feats_cand[sel_neg_idx_local]
                selected_neg_idx = neg_cand[sel_neg_idx_local]
            else:
                # compute similarity of neg candidates to p_pos
                neg_norm = F.normalize(neg_feats_cand, dim=1)
                p_pos_norm = F.normalize(p_pos, dim=1)
                sims_neg = (neg_norm @ p_pos_norm.t()).squeeze(1)  # (N,)
                Kneg = min(L, neg_feats_cand.shape[0])
                if Kneg == neg_feats_cand.shape[0]:
                    sel_neg_idx_local = torch.arange(neg_feats_cand.shape[0], device=device)
                else:
                    # hard negatives = those *most* similar to p_pos (highest sims)
                    _, order_neg = torch.topk(sims_neg, k=Kneg, largest=True)
                    sel_neg_idx_local = order_neg
                selected_neg_feats = neg_feats_cand[sel_neg_idx_local]
                selected_neg_idx = neg_cand[sel_neg_idx_local]

        results.append({
            'pos_feats': selected_pos_feats,    # (<=L, C)
            'neg_feats': selected_neg_feats,    # (<=L, C)
            'pos_idx': selected_pos_idx,        # flattened indices
            'neg_idx': selected_neg_idx
        })

    return results
