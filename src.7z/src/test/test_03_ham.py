# src/test/test_03_ham.py
"""
Test for Hybrid Attention Module (HAM)
 - Loads one sample
 - Runs backbone to obtain c5
 - Runs HAM on c5 and prints shapes
 - Visualizes a simple spatial attention heatmap (by summing absolute sam output)
"""

import os
import sys
import torch
import matplotlib.pyplot as plt

# Ensure src is importable (when running from src/test)
HERE = os.path.dirname(__file__)
SRC_ROOT = os.path.abspath(os.path.join(HERE, ".."))
if SRC_ROOT not in sys.path:
    sys.path.insert(0, SRC_ROOT)

from data.casia2_dataset import CASIA2Dataset
from models.backbone import ResNet50Backbone
from models.hybrid_attention import HybridAttention, NonLocalSpatialAttention

def show_heatmap(arr, title="Heatmap"):
    plt.figure(figsize=(4,4))
    plt.imshow(arr, cmap="jet")
    plt.colorbar(fraction=0.046, pad=0.04)
    plt.title(title)
    plt.axis("off")
    plt.show()

def main():
    # dataset root
    casia_root = os.path.abspath(os.path.join(SRC_ROOT, "..", "data", "CASIA2"))
    dataset = CASIA2Dataset(root=casia_root, input_size=512, train=False)
    sample = dataset[0]
    img = sample["image"].unsqueeze(0)   # (1,3,512,512)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("Using device:", device)

    # Backbone (get c5)
    backbone = ResNet50Backbone(pretrained=True).to(device)
    backbone.eval()
    with torch.no_grad():
        feats = backbone(img.to(device))
    c5 = feats["c5"]
    print("c5 shape:", c5.shape)

    # HAM
    ham = HybridAttention(in_channels=c5.shape[1]).to(device)
    ham.eval()
    with torch.no_grad():
        c5_hat = ham(c5)
    print("c5_hat shape:", c5_hat.shape)

    # Spatial attention heatmap (approx): use NonLocal internally to get sam out
    # We can instantiate a NonLocalSpatialAttention and get its output to visualize importance.
    sam = NonLocalSpatialAttention(in_channels=c5.shape[1]).to(device)
    sam.eval()
    with torch.no_grad():
        sam_out = sam(c5)            # (1, C, H, W)

    # Convert sam_out to spatial map: take absolute, sum over channels, normalize
    heat = sam_out.abs().sum(dim=1, keepdim=False).squeeze(0)  # (H, W)
    heat = heat.cpu().numpy()
    # normalize to [0,1]
    heat = (heat - heat.min()) / (heat.max() - heat.min() + 1e-8)

    # Upsample heatmap to input size for visualization (optional)
    heat_up = torch.tensor(heat).unsqueeze(0).unsqueeze(0)  # (1,1,H,W)
    heat_up = torch.nn.functional.interpolate(heat_up, size=(512,512), mode="bilinear", align_corners=False)
    heat_up = heat_up.squeeze().numpy()

    # Show heatmap
    show_heatmap(heat_up, title="SAM-derived spatial attention (upsampled)")

    print("HAM test complete.")

if __name__ == "__main__":
    main()
