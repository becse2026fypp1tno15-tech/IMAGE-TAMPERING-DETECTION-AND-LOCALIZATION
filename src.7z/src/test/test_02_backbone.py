# src/test/test_02_backbone.py
"""
Backbone test (ResNet50).
This script ensures the 'src' folder is added to sys.path so imports work
when run from src/test or src. It loads one sample from CASIA2 and runs
it through the ResNet50Backbone, printing multi-scale feature shapes.
"""

import os
import sys
import torch
import matplotlib.pyplot as plt

# -----------------------------
# Ensure src is on sys.path
# -----------------------------
HERE = os.path.dirname(__file__)                  # .../path/to/project/src/test
SRC_ROOT = os.path.abspath(os.path.join(HERE, ".."))  # .../path/to/project/src
if SRC_ROOT not in sys.path:
    sys.path.insert(0, SRC_ROOT)

print("DEBUG: inserted to sys.path:", SRC_ROOT)

# Now safe to import project modules
from data.casia2_dataset import CASIA2Dataset
from models.backbone import ResNet50Backbone

# Helper for image display
def show_image(tensor, title="Image"):
    mean = torch.tensor([0.485,0.456,0.406]).view(3,1,1)
    std  = torch.tensor([0.229,0.224,0.225]).view(3,1,1)
    img = (tensor * std + mean).clamp(0,1)
    img = img.permute(1,2,0).cpu().numpy()
    plt.figure(figsize=(4,4))
    plt.imshow(img)
    plt.title(title)
    plt.axis("off")
    plt.show()

def main():
    print("\n===== TESTING BACKBONE MODULE =====")

    # Resolve CASIA2 root relative to src/
    casia_root = os.path.abspath(os.path.join(SRC_ROOT, "..", "data", "CASIA2"))
    print("Using CASIA2 root:", casia_root)

    # Load one sample from dataset
    dataset = CASIA2Dataset(root=casia_root, input_size=512, train=False)

    if len(dataset) == 0:
        raise RuntimeError("Dataset is empty. Check CASIA2 path and files.")

    sample = dataset[0]
    image = sample["image"]

    print("[INFO] Loaded sample for backbone test")
    print("Image shape:", image.shape)

    # Optional: display the input image (comment out if running headless)
    try:
        show_image(image, "Backbone Input Image")
    except Exception as e:
        print("Warning: could not display image (headless?).", e)

    # Select device
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("Using device:", device)

    # Initialize backbone (set pretrained=False if you don't want to download weights)
    model = ResNet50Backbone(pretrained=True).to(device)
    model.eval()

    # Run forward pass
    x = image.unsqueeze(0).to(device)

    with torch.no_grad():
        features = model(x)

    # Print shapes of multi-scale features
    print("\n----- BACKBONE FEATURE MAP SHAPES -----")
    for key in ["c2", "c3", "c4", "c5"]:
        f = features[key]
        print(f"{key}: {tuple(f.shape)}")

    print("\nExpected sizes for 512x512 input:")
    print(" c2 → 128×128")
    print(" c3 → 64×64")
    print(" c4 → 32×32")
    print(" c5 → 16×16")
    print("\n===== BACKBONE MODULE TEST COMPLETE =====")

if __name__ == "__main__":
    main()
