# src/test/test_05_decoder.py
"""
Test the Decoder: backbone -> HAM -> Decoder
Print shapes and visualize final mask (upsampled to 512x512).
"""

import os
import sys
import torch
import matplotlib.pyplot as plt
import torch.nn.functional as F

# Ensure src is importable
HERE = os.path.dirname(__file__)
SRC_ROOT = os.path.abspath(os.path.join(HERE, ".."))
if SRC_ROOT not in sys.path:
    sys.path.insert(0, SRC_ROOT)

from data.casia2_dataset import CASIA2Dataset
from models.backbone import ResNet50Backbone
from models.hybrid_attention import HybridAttention
from models.decoder import SimpleDecoder

def show_image(tensor, title="Image"):
    mean = torch.tensor([0.485,0.456,0.406]).view(3,1,1)
    std  = torch.tensor([0.229,0.224,0.225]).view(3,1,1)
    img = (tensor * std + mean).clamp(0,1)
    img = img.permute(1,2,0).cpu().numpy()
    plt.figure(figsize=(4,4))
    plt.imshow(img)
    plt.title(title)
    plt.axis("off")
    plt.show()

def show_mask_np(arr, title="Mask"):
    plt.figure(figsize=(4,4))
    plt.imshow(arr, cmap='gray')
    plt.title(title)
    plt.axis("off")
    plt.show()

def main():
    casia_root = os.path.abspath(os.path.join(SRC_ROOT, "..", "data", "CASIA2"))
    dataset = CASIA2Dataset(root=casia_root, input_size=512, train=False)
    sample = dataset[0]
    img = sample["image"].unsqueeze(0)  # (1,3,512,512)
    H_in, W_in = 512, 512

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("Using device:", device)

    # Backbone
    backbone = ResNet50Backbone(pretrained=True).to(device)
    backbone.eval()
    with torch.no_grad():
        feats = backbone(img.to(device))
    c2, c3, c4, c5 = feats['c2'], feats['c3'], feats['c4'], feats['c5']
    print("Backbone shapes: c2", tuple(c2.shape), "c3", tuple(c3.shape), "c4", tuple(c4.shape), "c5", tuple(c5.shape))

    # HAM
    ham = HybridAttention(in_channels=c5.shape[1]).to(device)
    ham.eval()
    with torch.no_grad():
        c5_hat = ham(c5.to(device))
    print("c5_hat:", tuple(c5_hat.shape))

    # Decoder
    decoder = SimpleDecoder().to(device)
    decoder.eval()
    with torch.no_grad():
        mask_logits_up, boundaries, final_feat = decoder({'c2':c2, 'c3':c3, 'c4':c4}, c5_hat, input_size=(H_in,W_in))

    print("Decoder outputs:")
    print("  mask_logits_up:", tuple(mask_logits_up.shape))
    print("  boundary b4:", tuple(boundaries['b4'].shape))
    print("  boundary b3:", tuple(boundaries['b3'].shape))
    print("  boundary b2:", tuple(boundaries['b2'].shape))
    print("  final_feat:", tuple(final_feat.shape))

    # Visualize inputs & output
    show_image(sample["image"], "Input Image")
    # mask: apply sigmoid then convert to numpy
    mask_prob = torch.sigmoid(mask_logits_up).squeeze(0).squeeze(0).cpu().numpy()
    show_mask_np(mask_prob, "Predicted Mask (prob)")

    # visualize boundary b2 upsized to input
    b2_up = F.interpolate(boundaries['b2'], size=(H_in,W_in), mode='bilinear', align_corners=False).squeeze().cpu().numpy()
    show_mask_np(b2_up, "Boundary b2 (upsampled)")

if __name__ == "__main__":
    main()
