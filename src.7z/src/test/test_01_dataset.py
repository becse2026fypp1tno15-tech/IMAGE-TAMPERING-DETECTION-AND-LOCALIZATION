# src/test_modules.py
"""
Test script for the CASIA2 dataset + preprocessing.

This script ensures the `src` directory is on sys.path, then imports
the dataset module as `data.casia2_dataset`. Works when run from:
 - project_root/src
 - project_root/src/test
"""

import os
import sys
import torch
import matplotlib.pyplot as plt

# -----------------------------
# Compute and insert src/ into sys.path
# -----------------------------
HERE = os.path.dirname(__file__)                 # .../path/to/project/src (if run from src) or src/test (if run from src/test)
# Ensure SRC_ROOT points to the src/ folder (parent of test/ if we're inside test/)
SRC_ROOT = os.path.abspath(os.path.join(HERE, ".."))  # one level up from this file
# If this file is already directly inside src/ (i.e. you run from src), SRC_ROOT will be src/
# If you run from src/test/, SRC_ROOT will also resolve to src/
if SRC_ROOT not in sys.path:
    sys.path.insert(0, SRC_ROOT)

print("DEBUG: inserted to sys.path:", SRC_ROOT)

# -----------------------------
# Now import dataset module from src/data
# -----------------------------
from data.casia2_dataset import CASIA2Dataset

# -----------------------------
# Visualization helpers
# -----------------------------
def show_mask(mask, title="Mask"):
    arr = mask.squeeze(0).cpu().numpy()
    plt.figure(figsize=(5,5))
    plt.imshow(arr, cmap="gray")
    plt.title(title)
    plt.axis("off")
    plt.show()

def show_image(tensor, title="Image"):
    # Un-normalize the ImageNet-normalized tensor and display
    mean = torch.tensor([0.485, 0.456, 0.406]).view(3,1,1)
    std  = torch.tensor([0.229, 0.224, 0.225]).view(3,1,1)
    img = (tensor * std + mean).clamp(0,1)
    img = img.permute(1,2,0).cpu().numpy()
    plt.figure(figsize=(5,5))
    plt.imshow(img)
    plt.title(title)
    plt.axis("off")
    plt.show()

# -----------------------------
# Main test
# -----------------------------
def main():
    # Determine CASIA2 root relative to src/
    casia_root = os.path.abspath(os.path.join(SRC_ROOT, "..", "data", "CASIA2"))
    print("Using CASIA2 root:", casia_root)

    dataset = CASIA2Dataset(root=casia_root, input_size=512, train=True)

    if len(dataset) == 0:
        raise RuntimeError("CASIA2 dataset is empty. Check dataset path and files.")

    # pick a safe index (10 or last)
    idx = min(10, len(dataset)-1)
    sample = dataset[idx]

    print("\n--- SAMPLE INFORMATION ---")
    print("Index:", idx)
    print("Image path:", sample["img_path"])
    print("Mask path:", sample["mask_path"])
    print("Image shape:", sample["image"].shape)
    print("Mask shape:", sample["mask"].shape)
    print("Boundary shape:", sample["boundary"].shape)

    # Visualize
    show_image(sample["image"], "Preprocessed Image")
    show_mask(sample["mask"], "Mask GT")
    show_mask(sample["boundary"], "Boundary GT")

if __name__ == "__main__":
    main()
