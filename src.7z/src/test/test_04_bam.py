# src/test/test_04_bam.py
"""
Test for Boundary-Aware Attention Module (BAM).
We use actual c4 (encoder) and c5_hat (from backbone+HAM) to run one BAM stage.
"""

import os
import sys
import torch

# ensure src is importable
HERE = os.path.dirname(__file__)
SRC_ROOT = os.path.abspath(os.path.join(HERE, ".."))
if SRC_ROOT not in sys.path:
    sys.path.insert(0, SRC_ROOT)

from data.casia2_dataset import CASIA2Dataset
from models.backbone import ResNet50Backbone
from models.hybrid_attention import HybridAttention
from models.bam import BAM

def main():
    casia_root = os.path.abspath(os.path.join(SRC_ROOT, "..", "data", "CASIA2"))
    dataset = CASIA2Dataset(root=casia_root, input_size=512, train=False)
    sample = dataset[0]
    img = sample["image"].unsqueeze(0)  # (1,3,512,512)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("Using device:", device)

    # Backbone
    backbone = ResNet50Backbone(pretrained=True).to(device)
    backbone.eval()
    with torch.no_grad():
        feats = backbone(img.to(device))
    c2, c3, c4, c5 = feats["c2"], feats["c3"], feats["c4"], feats["c5"]
    print("Shapes: c2", tuple(c2.shape), "c3", tuple(c3.shape), "c4", tuple(c4.shape), "c5", tuple(c5.shape))

    # HAM on c5
    ham = HybridAttention(in_channels=c5.shape[1]).to(device)
    ham.eval()
    with torch.no_grad():
        c5_hat = ham(c5.to(device))
    print("c5_hat shape:", tuple(c5_hat.shape))

    # Now run BAM: use c4 as Xi and c5_hat as Xhat_next
    bam = BAM(enc_channels=c4.shape[1], dec_channels=c5_hat.shape[1], topk=32, embed_dim=256).to(device)
    bam.eval()
    with torch.no_grad():
        X_hat_i, boundary_up = bam(c4.to(device), c5_hat.to(device))

    print("BAM outputs shapes:")
    print("X_hat_i:", tuple(X_hat_i.shape))     # expected (1, Ce, He, We) == c4 spatial
    print("boundary_up:", tuple(boundary_up.shape))  # (1,1,He,We) same spatial as c4

    # Quick sanity checks
    if X_hat_i.shape[2:] != c4.shape[2:]:
        print("Warning: X_hat_i spatial size mismatch with c4 (expected to match encoder spatial).")

    print("BAM test complete.")

if __name__ == '__main__':
    main()
