# src/test/test_08_sampler.py
"""
Unit test for boundary-guided sampler.

It:
 - loads one CASIA2 sample
 - runs backbone->HAM->decoder to obtain final_feat
 - runs sample_hard_examples on final_feat + mask_gt
 - prints counts, shapes, and shows visualization of sampled coordinates overlayed
"""

import os
import sys
import torch
import matplotlib.pyplot as plt

# bootstrap src imports
HERE = os.path.dirname(__file__)
SRC_ROOT = os.path.abspath(os.path.join(HERE, ".."))
if SRC_ROOT not in sys.path:
    sys.path.insert(0, SRC_ROOT)

from data.casia2_dataset import CASIA2Dataset
from models.backbone import ResNet50Backbone
from models.hybrid_attention import HybridAttention
from models.decoder import SimpleDecoder
from losses.boundary_sampler import sample_hard_examples

import torch.nn.functional as F

def show_mask_with_points(mask_arr, pos_coords, neg_coords, title="Samples"):
    """
    mask_arr: numpy HxW
    pos_coords, neg_coords: lists/tensors of flattened indices or (row,col) coords
    """
    plt.figure(figsize=(5,5))
    plt.imshow(mask_arr, cmap='gray')
    if pos_coords is not None and len(pos_coords) > 0:
        ys, xs = zip(*pos_coords)
        plt.scatter(xs, ys, s=8, c='red', label='pos')
    if neg_coords is not None and len(neg_coords) > 0:
        ys, xs = zip(*neg_coords)
        plt.scatter(xs, ys, s=8, c='cyan', label='neg')
    plt.legend()
    plt.title(title)
    plt.axis('off')
    plt.show()


def flat_idx_to_coords(idxs, H, W):
    """Convert flattened indices to (row, col) coords"""
    if idxs.numel() == 0:
        return []
    idxs = idxs.cpu().numpy().astype(int)
    rows = idxs // W
    cols = idxs % W
    return list(zip(rows.tolist(), cols.tolist()))


def main():
    casia_root = os.path.abspath(os.path.join(SRC_ROOT, "..", "data", "CASIA2"))
    dataset = CASIA2Dataset(root=casia_root, input_size=512, train=False)
    sample = dataset[0]
    img = sample["image"].unsqueeze(0)
    mask_gt = sample["mask"].unsqueeze(0)  # (1,1,512,512)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("Using device:", device)

    # backbone -> ham -> decoder to get final features
    backbone = ResNet50Backbone(pretrained=True).to(device)
    ham = HybridAttention(in_channels=2048).to(device)
    decoder = SimpleDecoder().to(device)

    backbone.eval(); ham.eval(); decoder.eval()
    with torch.no_grad():
        feats = backbone(img.to(device))
        c5_hat = ham(feats['c5'])
        mask_logits_up, boundaries, final_feat = decoder({'c2':feats['c2'], 'c3':feats['c3'], 'c4':feats['c4']},
                                                         c5_hat, input_size=(512,512))

    print("Final feature shape:", tuple(final_feat.shape))  # (1, C, Hf, Wf)
    B, C, Hf, Wf = final_feat.shape

    # Run sampler
    Z = 500
    L = 256
    dilation = 3
    sampled = sample_hard_examples(final_feat, mask_gt, Z=Z, L=L, dilation=dilation, device=device)

    # Inspect batch element 0
    r = sampled[0]
    pos_feats = r['pos_feats']
    neg_feats = r['neg_feats']
    pos_idx = r['pos_idx']
    neg_idx = r['neg_idx']

    print("Sampled candidates (requested Z={}):".format(Z))
    print(" Selected positive count (<=L):", pos_feats.shape[0])
    print(" Selected negative count (<=L):", neg_feats.shape[0])
    print(" pos_idx shape:", tuple(pos_idx.shape))
    print(" neg_idx shape:", tuple(neg_idx.shape))

    # Convert mask to numpy at feature spatial for visualization
    mask_small = F.interpolate(mask_gt.to(device), size=(Hf, Wf), mode='nearest').squeeze().cpu().numpy()

    # Convert indices to coordinates
    pos_coords = flat_idx_to_coords(pos_idx if pos_idx is not None else torch.tensor([], device=device), Hf, Wf)
    neg_coords = flat_idx_to_coords(neg_idx if neg_idx is not None else torch.tensor([], device=device), Hf, Wf)

    # show overlay
    show_mask_with_points(mask_small, pos_coords[:200], neg_coords[:200], title=f"Sampled points (Hf={Hf} Wf={Wf})")

    print("Sampler test complete.")

if __name__ == "__main__":
    main()
