#!/usr/bin/env python3
"""
evaluate_columbia.py

Cross-test model on Columbia dataset, compute metrics and optionally save visuals.

Outputs into: <save_dir>/eval_out/columbia/
 - columbia_summary_fixed.json
 - columbia_per_image_fixed.csv
 - columbia_summary_sweep.json (if --sweep)
 - columbia_per_image_sweep.csv (if --sweep)
 - vis/ (optional overlay PNGs)
 - pred_masks_npy/ (optional mask probability arrays)
"""
import os
import argparse
import json
import csv
from pathlib import Path
from collections import defaultdict
from tqdm import tqdm

import numpy as np
from PIL import Image
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

import torch
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

# add repo src root to path
import sys
HERE = os.path.dirname(__file__)
if HERE not in sys.path:
    sys.path.insert(0, HERE)

from models.full_model import FullModel

IMG_NET_SIZE = 512  # model input size used during training
IMG_EXTS = {".bmp", ".png", ".jpg", ".jpeg", ".tif", ".tiff"}


# -------------------------
# Dataset + flexible mask discovery
# -------------------------
class ColumbiaDataset(Dataset):
    """
    Recursively scan root_dir/<subfolders> for images. Try to find masks with flexible patterns.
    Returns images preprocessed for model, plus orig size and mask (if found, at network size).
    """

    def __init__(self, root_dir):
        self.root = Path(root_dir)
        if not self.root.exists():
            raise RuntimeError(f"Data root not found: {root_dir}")

        items = []
        for sub in sorted(self.root.iterdir()):
            if not sub.is_dir():
                continue
            for p in sorted(sub.iterdir()):
                if not p.is_file():
                    continue
                if p.suffix.lower() in IMG_EXTS:
                    rel = str(p.relative_to(self.root))
                    mask = self._find_mask_for_image(p)
                    items.append({"img": str(p), "mask": mask, "rel": rel})
        if len(items) == 0:
            raise RuntimeError(f"No images found in {root_dir}")
        self.items = items

    def _find_mask_for_image(self, img_path: Path):
        stem = img_path.stem
        folder = img_path.parent

        # Candidate names in same folder
        cand_names = [
            f"{stem}_gt.png", f"{stem}_gt.bmp", f"{stem}_mask.png", f"{stem}_mask.bmp",
            f"{stem}.png", f"{stem}.bmp", f"{stem}.PNG", f"{stem}.BMP"
        ]
        for c in cand_names:
            p = folder / c
            if p.exists():
                return str(p)

        # Try sibling 'gt' or 'groundtruth' folders
        for sibling in folder.parent.iterdir():
            if not sibling.is_dir():
                continue
            if sibling.name.lower() in {"gt", "gtpng", "groundtruth", "ground_truth", "masks", "mask", "ground-truth"}:
                candidates = [
                    sibling / f"{stem}_gt.png",
                    sibling / f"{stem}.png",
                    sibling / f"{stem}_mask.png",
                ]
                for p in candidates:
                    if p.exists():
                        return str(p)

        # Not found
        return None

    def __len__(self):
        return len(self.items)

    def __getitem__(self, idx):
        rec = self.items[idx]
        img_path = rec["img"]
        mask_path = rec["mask"]
        rel = rec["rel"]

        img = Image.open(img_path).convert("RGB")
        orig_w, orig_h = img.size

        # model input preprocessing (resize to network size)
        inp = img.resize((IMG_NET_SIZE, IMG_NET_SIZE), Image.BILINEAR)
        arr = np.array(inp).astype(np.float32) / 255.0
        mean = np.array([0.485, 0.456, 0.406], dtype=np.float32)
        std  = np.array([0.229, 0.224, 0.225], dtype=np.float32)
        arr = (arr - mean) / std
        arr = np.transpose(arr, (2, 0, 1)).copy()
        tensor = torch.from_numpy(arr)

        mask_arr = None
        if mask_path is not None:
            try:
                m = Image.open(mask_path).convert("L")
                # convert to network size (NN)
                m = m.resize((IMG_NET_SIZE, IMG_NET_SIZE), Image.NEAREST)
                m_arr = (np.array(m).astype(np.uint8) > 127).astype(np.uint8)
                mask_arr = m_arr
            except Exception:
                mask_arr = None

        return {
            "image": tensor,            # Tensor (3,H,W)
            "abs_path": img_path,       # string
            "rel_path": rel,            # string relative to dataset root
            "orig_size": (orig_w, orig_h),  # tuple (w,h)
            "mask": mask_arr            # numpy array HxW (network size) or None
        }


# -------------------------
# collate that keeps lists for metadata
# -------------------------
def collate_keep_meta(batch):
    imgs = torch.stack([b["image"] for b in batch], dim=0)
    abs_paths = [b["abs_path"] for b in batch]
    rel_paths = [b["rel_path"] for b in batch]
    orig_sizes = [b["orig_size"] for b in batch]
    masks = [b["mask"] for b in batch]  # may be None or numpy arrays
    return {
        "image": imgs,
        "abs_path": abs_paths,
        "rel_path": rel_paths,
        "orig_size": orig_sizes,
        "mask": masks
    }


# -------------------------
# helpers: metrics + visualization
# -------------------------
def compute_prf_iou_from_binary(pred_bin, gt_bin, eps=1e-8):
    pred = pred_bin.astype(np.uint8)
    gt = gt_bin.astype(np.uint8)
    tp = int((pred & gt).sum())
    fp = int((pred & (1 - gt)).sum())
    fn = int(((1 - pred) & gt).sum())
    prec = tp / (tp + fp + eps)
    rec  = tp / (tp + fn + eps)
    f1   = 2 * prec * rec / (prec + rec + eps)
    inter = int((pred & gt).sum())
    union = int((pred | gt).sum())
    iou = inter / (union + eps)
    return prec, rec, f1, iou


def save_overlay(original_image_path, mask_prob_resized, bin_mask, out_path):
    img = Image.open(original_image_path).convert("RGB")
    img_arr = np.array(img).astype(np.uint8)

    cmap = plt.get_cmap("jet")
    heat = (cmap(mask_prob_resized)[:, :, :3] * 255).astype(np.uint8)

    alpha = 0.5
    overlay = img_arr.copy()
    mask_idx = bin_mask.astype(bool)
    overlay[mask_idx] = (alpha * heat[mask_idx] + (1 - alpha) * img_arr[mask_idx]).astype(np.uint8)

    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    axes[0].imshow(img_arr); axes[0].set_title("Original"); axes[0].axis("off")
    axes[1].imshow(mask_prob_resized, cmap="jet"); axes[1].set_title("Mask prob"); axes[1].axis("off")
    axes[2].imshow(overlay); axes[2].set_title("Overlay (bin mask)"); axes[2].axis("off")
    plt.tight_layout()
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


# -------------------------
# main
# -------------------------
def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--data-root", type=str, required=True)
    p.add_argument("--ckpt", type=str, required=True)
    p.add_argument("--save-dir", type=str, default="../checkpoints")
    p.add_argument("--batch-size", type=int, default=16)
    p.add_argument("--num-workers", type=int, default=4)
    p.add_argument("--device", type=str, default="cuda")
    p.add_argument("--visualize", action="store_true", help="save overlay visuals")
    p.add_argument("--save-probs", action="store_true", help="save mask probability .npy files")
    p.add_argument("--sweep", action="store_true", help="do per-image best-threshold sweep (slow)")
    p.add_argument("--thresh-steps", type=int, default=200)
    return p.parse_args()


def main():
    args = parse_args()
    device = torch.device(args.device if torch.cuda.is_available() and args.device == "cuda" else "cpu")
    print("Device:", device)
    print("Data root:", args.data_root)
    print("Checkpoint:", args.ckpt)

    out_dir = os.path.join(args.save_dir, "eval_out", "columbia")
    os.makedirs(out_dir, exist_ok=True)
    vis_dir = os.path.join(out_dir, "vis")
    probs_dir = os.path.join(out_dir, "pred_masks_npy")
    if args.visualize:
        os.makedirs(vis_dir, exist_ok=True)
    if args.save_probs:
        os.makedirs(probs_dir, exist_ok=True)

    ds = ColumbiaDataset(args.data_root)
    loader = DataLoader(ds, batch_size=args.batch_size, shuffle=False,
                        num_workers=args.num_workers, pin_memory=True, collate_fn=collate_keep_meta)

    # load model
    model = FullModel(pretrained_backbone=True).to(device)
    ckpt = torch.load(args.ckpt, map_location=device)
    if isinstance(ckpt, dict) and "model_state" in ckpt:
        model.load_state_dict(ckpt["model_state"])
    else:
        model.load_state_dict(ckpt)
    model.eval()
    print("Loaded checkpoint.")

    # fixed threshold storage
    per_image_fixed = []
    fixed_tp = fixed_fp = fixed_fn = 0
    n_with_mask = 0
    mask_threshold = 0.5

    # sweep storage
    per_image_sweep = []
    thresholds = np.linspace(0.0, 1.0, args.thresh_steps) if args.sweep else None

    with torch.no_grad():
        for batch in tqdm(loader, desc="Evaluating Columbia"):
            imgs = batch["image"].to(device)
            rels = batch["rel_path"]
            abs_paths = batch["abs_path"]
            orig_sizes = batch["orig_size"]  # list of tuples
            masks_net = batch["mask"]        # list of numpy arrays or None

            out = model(imgs, return_all=True)
            logits = out.get("mask_logits_up", None)
            if logits is None:
                raise RuntimeError("Model did not return 'mask_logits_up' in output")

            probs = torch.sigmoid(logits).cpu().numpy()  # (B,1,Hnet,Wnet)
            probs = probs[:, 0, :, :]  # (B,Hnet,Wnet)

            for i in range(probs.shape[0]):
                prob_map = probs[i]
                rel = rels[i]
                abs_path = abs_paths[i]
                orig_w, orig_h = orig_sizes[i][0], orig_sizes[i][1]

                # resize prob_map to original size
                prob_img = Image.fromarray((prob_map * 255).astype(np.uint8))
                prob_img = prob_img.resize((orig_w, orig_h), resample=Image.BILINEAR)
                prob_arr = (np.array(prob_img).astype(np.float32) / 255.0)

                # fixed threshold binarization
                bin_mask = (prob_arr >= mask_threshold).astype(np.uint8)

                # optionally save .npy
                safe_rel = rel.replace(os.sep, "_").replace("/", "_")
                if args.save_probs:
                    npy_path = os.path.join(probs_dir, f"{safe_rel}.npy")
                    np.save(npy_path, prob_arr.astype(np.float32))

                # optionally save visual overlay
                if args.visualize:
                    vis_out = os.path.join(vis_dir, f"{safe_rel}.png")
                    save_overlay(abs_path, prob_arr, bin_mask, vis_out)

                # compute per-pixel metrics only if GT mask exists
                gt_net = masks_net[i]  # network-sized mask or None
                if gt_net is not None:
                    # resize gt_net to original size to match prob_arr
                    gt_img = Image.fromarray((gt_net * 255).astype(np.uint8))
                    gt_img = gt_img.resize((orig_w, orig_h), resample=Image.NEAREST)
                    gt_arr = (np.array(gt_img).astype(np.uint8) > 127).astype(np.uint8)

                    p, r, f1, iou = compute_prf_iou_from_binary(bin_mask, gt_arr)
                    per_image_fixed.append({
                        "rel_path": rel,
                        "precision": float(p),
                        "recall": float(r),
                        "f1": float(f1),
                        "iou": float(iou)
                    })
                    fixed_tp += int((bin_mask & gt_arr).sum())
                    fixed_fp += int((bin_mask & (1 - gt_arr)).sum())
                    fixed_fn += int(((1 - bin_mask) & gt_arr).sum())
                    n_with_mask += 1

                    if args.sweep:
                        best_f1 = -1.0
                        best_stats = (0.0, 0.0, 0.0, 0.0, 0.0)
                        for t in thresholds:
                            b = (prob_arr >= t).astype(np.uint8)
                            prec, rec, f1_t, iou_t = compute_prf_iou_from_binary(b, gt_arr)
                            if (f1_t > best_f1) or (abs(f1_t - best_f1) < 1e-12 and iou_t > best_stats[3]):
                                best_f1 = f1_t
                                best_stats = (prec, rec, f1_t, iou_t, float(t))
                        per_image_sweep.append({
                            "rel_path": rel,
                            "best_thresh": best_stats[4],
                            "precision": float(best_stats[0]),
                            "recall": float(best_stats[1]),
                            "f1": float(best_stats[2]),
                            "iou": float(best_stats[3])
                        })
                else:
                    # no GT: store placeholders
                    per_image_fixed.append({
                        "rel_path": rel,
                        "precision": None,
                        "recall": None,
                        "f1": None,
                        "iou": None
                    })
                    if args.sweep:
                        per_image_sweep.append({
                            "rel_path": rel,
                            "best_thresh": None,
                            "precision": None,
                            "recall": None,
                            "f1": None,
                            "iou": None
                        })

    # aggregate fixed-threshold metrics
    summary_fixed = {}
    if n_with_mask > 0:
        prec = fixed_tp / (fixed_tp + fixed_fp + 1e-8)
        rec  = fixed_tp / (fixed_tp + fixed_fn + 1e-8)
        f1   = 2 * prec * rec / (prec + rec + 1e-8)
        iou  = fixed_tp / (fixed_tp + fixed_fp + fixed_fn + 1e-8)
        summary_fixed = {
            "dataset": "columbia",
            "samples_with_mask": n_with_mask,
            "threshold": mask_threshold,
            "precision": float(prec),
            "recall": float(rec),
            "f1": float(f1),
            "iou": float(iou),
            "num_images_total": len(ds)
        }

    # write fixed results
    fixed_json = os.path.join(out_dir, "columbia_summary_fixed.json")
    fixed_csv  = os.path.join(out_dir, "columbia_per_image_fixed.csv")
    with open(fixed_json, "w") as f:
        json.dump(summary_fixed, f, indent=2)
    with open(fixed_csv, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["rel_path","precision","recall","f1","iou"])
        writer.writeheader()
        for row in per_image_fixed:
            writer.writerow(row)

    print("\n=== COLUMBIA EVAL (fixed threshold=0.5) ===")
    if summary_fixed:
        print(f"Images with masks      : {summary_fixed['samples_with_mask']}")
        print(f"Precision @0.5         : {summary_fixed['precision']:.4f}")
        print(f"Recall    @0.5         : {summary_fixed['recall']:.4f}")
        print(f"F1        @0.5         : {summary_fixed['f1']:.4f}")
        print(f"IoU       @0.5         : {summary_fixed['iou']:.4f}")
    else:
        print("No ground-truth masks found; fixed-threshold metrics omitted.")
    print("Saved per-image CSV:", fixed_csv)
    print("Saved summary JSON:", fixed_json)

    # sweep
    if args.sweep:
        n_sweep = sum(1 for r in per_image_sweep if r["f1"] is not None)
        if n_sweep > 0:
            mean_prec = np.mean([r["precision"] for r in per_image_sweep if r["precision"] is not None])
            mean_rec  = np.mean([r["recall"] for r in per_image_sweep if r["recall"] is not None])
            mean_f1   = np.mean([r["f1"] for r in per_image_sweep if r["f1"] is not None])
            mean_iou  = np.mean([r["iou"] for r in per_image_sweep if r["iou"] is not None])
            mean_t    = np.mean([r["best_thresh"] for r in per_image_sweep if r["best_thresh"] is not None])
        else:
            mean_prec = mean_rec = mean_f1 = mean_iou = mean_t = None

        sweep_summary = {
            "dataset": "columbia",
            "samples_with_mask": n_sweep,
            "mean_best_precision": mean_prec,
            "mean_best_recall": mean_rec,
            "mean_best_f1": mean_f1,
            "mean_best_iou": mean_iou,
            "mean_best_threshold": mean_t,
            "threshold_steps": int(args.thresh_steps)
        }

        sweep_json = os.path.join(out_dir, "columbia_summary_sweep.json")
        sweep_csv  = os.path.join(out_dir, "columbia_per_image_sweep.csv")
        with open(sweep_json, "w") as f:
            json.dump(sweep_summary, f, indent=2)
        with open(sweep_csv, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["rel_path","best_thresh","precision","recall","f1","iou"])
            writer.writeheader()
            for row in per_image_sweep:
                writer.writerow(row)

        print("\n=== COLUMBIA EVAL (per-image best-threshold sweep) ===")
        if mean_f1 is not None:
            print(f"Val samples (with mask): {n_sweep}")
            print(f"Mean Best-Precision : {mean_prec:.4f}")
            print(f"Mean Best-Recall    : {mean_rec:.4f}")
            print(f"Mean Best-F1        : {mean_f1:.4f}")
            print(f"Mean Best-IoU       : {mean_iou:.4f}")
            print(f"Mean Best-Threshold : {mean_t:.4f}")
        else:
            print("No sweep results (no masks found).")
        print("Saved JSON:", sweep_json)
        print("Saved CSV: ", sweep_csv)

    print("\nAll outputs saved under:", out_dir)


if __name__ == "__main__":
    main()
