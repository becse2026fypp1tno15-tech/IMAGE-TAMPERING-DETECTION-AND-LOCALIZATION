#!/usr/bin/env python3
"""
evaluate_defacto.py

Cross-test model (trained on CASIAv2) on DEFACTO dataset.
Uses probe_mask as ground truth (base-paper aligned).

Outputs into: <save_dir>/eval_out/defacto/
 - defacto_summary_fixed.json
 - defacto_per_image_fixed.csv
 - defacto_summary_sweep.json (if --sweep)
 - defacto_per_image_sweep.csv (if --sweep)
 - vis/ (sample overlay PNGs, limited)
"""

import os
import argparse
import json
import csv
from pathlib import Path
from tqdm import tqdm

import numpy as np
from PIL import Image
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

import torch
from torch.utils.data import Dataset, DataLoader

# add repo src root
import sys
HERE = os.path.dirname(__file__)
if HERE not in sys.path:
    sys.path.insert(0, HERE)

from models.full_model import FullModel

IMG_NET_SIZE = 512
IMG_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}

# -------------------------------------------------
# DEFACTO Dataset (uses probe_mask ONLY)
# -------------------------------------------------
class DefactoDataset(Dataset):
    def __init__(self, root_dir):
        self.root = Path(root_dir)
        self.items = []

        for manip in sorted(self.root.iterdir()):
            if not manip.is_dir():
                continue

            # image folders
            for img_dir in manip.glob("*_img/img"):
                ann_dir = img_dir.parent.parent / (img_dir.parent.name.replace("_img", "_annotations")) / "probe_mask"
                if not ann_dir.exists():
                    continue

                for img_path in sorted(img_dir.iterdir()):
                    if img_path.suffix.lower() not in IMG_EXTS:
                        continue

                    mask_path = ann_dir / img_path.name
                    if not mask_path.exists():
                        continue

                    self.items.append({
                        "img": str(img_path),
                        "mask": str(mask_path),
                        "rel": str(img_path.relative_to(self.root))
                    })

        if len(self.items) == 0:
            raise RuntimeError("No DEFACTO images found")

    def __len__(self):
        return len(self.items)

    def __getitem__(self, idx):
        rec = self.items[idx]
        img = Image.open(rec["img"]).convert("RGB")
        mask = Image.open(rec["mask"]).convert("L")

        orig_w, orig_h = img.size

        # preprocess image
        img_r = img.resize((IMG_NET_SIZE, IMG_NET_SIZE), Image.BILINEAR)
        arr = np.array(img_r).astype(np.float32) / 255.0
        mean = np.array([0.485,0.456,0.406], dtype=np.float32)
        std  = np.array([0.229,0.224,0.225], dtype=np.float32)
        arr = (arr - mean) / std
        arr = np.transpose(arr, (2,0,1))
        img_t = torch.from_numpy(arr)

        # preprocess mask
        mask_r = mask.resize((IMG_NET_SIZE, IMG_NET_SIZE), Image.NEAREST)
        mask_arr = (np.array(mask_r) > 127).astype(np.uint8)

        return {
            "image": img_t,
            "mask": mask_arr,
            "abs_path": rec["img"],
            "rel_path": rec["rel"],
            "orig_size": (orig_w, orig_h)
        }

# -------------------------------------------------
# Collate
# -------------------------------------------------
def collate(batch):
    return {
        "image": torch.stack([b["image"] for b in batch]),
        "mask": [b["mask"] for b in batch],
        "abs_path": [b["abs_path"] for b in batch],
        "rel_path": [b["rel_path"] for b in batch],
        "orig_size": [b["orig_size"] for b in batch],
    }

# -------------------------------------------------
# Metrics
# -------------------------------------------------
def prf_iou(pred, gt, eps=1e-8):
    tp = (pred & gt).sum()
    fp = (pred & (1-gt)).sum()
    fn = ((1-pred) & gt).sum()
    p = tp / (tp+fp+eps)
    r = tp / (tp+fn+eps)
    f1 = 2*p*r/(p+r+eps)
    iou = tp / (tp+fp+fn+eps)
    return p, r, f1, iou

# -------------------------------------------------
# Visualization
# -------------------------------------------------
def save_overlay(img_path, prob, bin_mask, out):
    img = np.array(Image.open(img_path).convert("RGB"))
    heat = (plt.get_cmap("jet")(prob)[:,:,:3] * 255).astype(np.uint8)
    overlay = img.copy()
    overlay[bin_mask==1] = (0.5*heat[bin_mask==1] + 0.5*img[bin_mask==1]).astype(np.uint8)

    fig, ax = plt.subplots(1,3, figsize=(15,5))
    ax[0].imshow(img); ax[0].set_title("Original"); ax[0].axis("off")
    ax[1].imshow(prob, cmap="jet"); ax[1].set_title("Mask prob"); ax[1].axis("off")
    ax[2].imshow(overlay); ax[2].set_title("Overlay"); ax[2].axis("off")
    plt.tight_layout()
    fig.savefig(out, dpi=150)
    plt.close(fig)

# -------------------------------------------------
# Main
# -------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-root", required=True)
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--save-dir", default="../checkpoints")
    ap.add_argument("--batch-size", type=int, default=16)
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--visualize", action="store_true")
    ap.add_argument("--sample-n", type=int, default=10)
    ap.add_argument("--sweep", action="store_true")
    ap.add_argument("--thresh-steps", type=int, default=200)
    args = ap.parse_args()

    device = torch.device(args.device if torch.cuda.is_available() else "cpu")

    out_dir = Path(args.save_dir) / "eval_out" / "defacto"
    vis_dir = out_dir / "vis"
    vis_dir.mkdir(parents=True, exist_ok=True)

    ds = DefactoDataset(args.data_root)
    loader = DataLoader(ds, batch_size=args.batch_size, collate_fn=collate)

    model = FullModel(pretrained_backbone=True).to(device)
    ckpt = torch.load(args.ckpt, map_location=device)
    model.load_state_dict(ckpt["model_state"] if "model_state" in ckpt else ckpt)
    model.eval()

    tp=fp=fn=0
    per_img = []
    vis_count = 0

    with torch.no_grad():
        for batch in tqdm(loader, desc="Evaluating DEFACTO"):
            imgs = batch["image"].to(device)
            masks = batch["mask"]
            out = model(imgs, return_all=True)
            probs = torch.sigmoid(out["mask_logits_up"]).cpu().numpy()[:,0]

            for i in range(len(masks)):
                prob = probs[i]
                ow, oh = batch["orig_size"][i]
                prob_r = np.array(Image.fromarray((prob*255).astype(np.uint8)).resize((ow,oh))) / 255.0
                binm = (prob_r >= 0.5).astype(np.uint8)

                gt = masks[i]
                gt_r = np.array(Image.fromarray((gt*255).astype(np.uint8)).resize((ow,oh))) > 0

                p,r,f1,iou = prf_iou(binm, gt_r)
                per_img.append({"rel":batch["rel_path"][i],"f1":float(f1),"iou":float(iou)})
                tp += (binm & gt_r).sum()
                fp += (binm & ~gt_r).sum()
                fn += ((~binm.astype(bool)) & gt_r).sum()

                if args.visualize and vis_count < args.sample_n:
                    save_overlay(batch["abs_path"][i], prob_r, binm,
                                 vis_dir / f"vis_{vis_count:03d}.png")
                    vis_count += 1

    prec = tp/(tp+fp+1e-8)
    rec = tp/(tp+fn+1e-8)
    f1 = 2*prec*rec/(prec+rec+1e-8)
    iou = tp/(tp+fp+fn+1e-8)

    summary = {
        "dataset":"defacto",
        "precision@0.5":float(prec),
        "recall@0.5":float(rec),
        "f1@0.5":float(f1),
        "iou@0.5":float(iou),
        "num_images":len(ds)
    }

    with open(out_dir/"defacto_summary_fixed.json","w") as f:
        json.dump(summary,f,indent=2)

    with open(out_dir/"defacto_per_image_fixed.csv","w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=per_img[0].keys())
        w.writeheader(); w.writerows(per_img)

    print("\n=== DEFACTO CROSS-TEST (BASE PAPER) ===")
    print(summary)
    print("Saved under:", out_dir)

if __name__ == "__main__":
    main()
