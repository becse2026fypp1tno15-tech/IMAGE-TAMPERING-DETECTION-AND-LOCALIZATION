"""
infer_with_refined_boundary.py

Inference with Dual-Branch Boundary Refinement (Post-Processing)

✔ Uses SAME trained base-paper model
✔ No retraining
✔ No architecture change
✔ Visualizes base vs refined clearly
✔ Single clean script (viva-friendly)
"""

import os
import argparse
import numpy as np
from PIL import Image

import torch

from models.full_model import FullModel
from data.transforms import Preprocessor
from extra.boundary_refinement import refine_boundary


# --------------------------------------------------
# Utils
# --------------------------------------------------
def save_gray(arr, path):
    arr = (np.clip(arr, 0, 1) * 255).astype(np.uint8)
    Image.fromarray(arr).save(path)


def overlay_boundary(image, boundary, color=(255, 0, 0)):
    out = image.copy()
    out[boundary > 0.5] = color
    return out


# --------------------------------------------------
# Inference
# --------------------------------------------------
def run_inference(args):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # -------------------------
    # Load model
    # -------------------------
    model = FullModel(pretrained_backbone=False).to(device)
    ckpt = torch.load(args.checkpoint, map_location=device)

    if isinstance(ckpt, dict) and "model_state" in ckpt:
        model.load_state_dict(ckpt["model_state"])
    else:
        model.load_state_dict(ckpt)

    model.eval()
    print("✅ Model loaded")

    # -------------------------
    # Load & preprocess image
    # -------------------------
    img = Image.open(args.image).convert("RGB")
    dummy_mask = Image.new("L", img.size, 0)

    preproc = Preprocessor(input_size=args.input_size, train=False)
    img_t, _, _ = preproc(img, dummy_mask)
    img_t = img_t.unsqueeze(0).to(device)

    with torch.no_grad():
        out = model(img_t, return_all=True)

    # -------------------------
    # Image-level prediction
    # -------------------------
    img_logit = out["image_logit"].view(1, 1)
    img_prob = torch.sigmoid(img_logit).item()
    label = "TAMPERED" if img_prob >= 0.5 else "AUTHENTIC"

    print("\n========== IMAGE-LEVEL RESULT ==========")
    print("Prediction :", label)
    print("Confidence :", f"{img_prob:.4f}")

    # -------------------------
    # Base-paper boundary
    # -------------------------
    boundary_raw = torch.sigmoid(
        out["boundary_logits_local"]
    )[0, 0].cpu().numpy()  # (128,128)

    H, W = boundary_raw.shape
    image_small = np.array(img.resize((W, H)))

    # -------------------------
    # OUR contribution: refinement
    # -------------------------
    boundary_refined = refine_boundary(boundary_raw, image_small)

    # -------------------------
    # Save outputs
    # -------------------------
    os.makedirs(args.out_dir, exist_ok=True)

    Image.fromarray(image_small).save(
        os.path.join(args.out_dir, "original.png")
    )

    save_gray(boundary_raw, os.path.join(args.out_dir, "boundary_raw.png"))
    save_gray(boundary_refined, os.path.join(args.out_dir, "boundary_refined.png"))

    overlay_base = overlay_boundary(image_small, boundary_raw)
    overlay_refined = overlay_boundary(image_small, boundary_refined)

    Image.fromarray(overlay_base).save(
        os.path.join(args.out_dir, "overlay_base.png")
    )
    Image.fromarray(overlay_refined).save(
        os.path.join(args.out_dir, "overlay_refined.png")
    )

    # -------------------------
    # FINAL comparison (BEST FOR VIVA)
    # -------------------------
    comparison = np.concatenate(
        [image_small, overlay_base, overlay_refined],
        axis=1
    )
    Image.fromarray(comparison).save(
        os.path.join(args.out_dir, "comparison.png")
    )

    print("\n✅ Results saved to:", args.out_dir)
    print("Left → Original | Middle → Base Paper | Right → Refined")


# --------------------------------------------------
# Args
# --------------------------------------------------
def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--image", required=True)
    p.add_argument("--checkpoint", required=True)
    p.add_argument("--out-dir", required=True)
    p.add_argument("--input-size", type=int, default=512)
    return p.parse_args()


if __name__ == "__main__":
    args = parse_args()
    run_inference(args)
