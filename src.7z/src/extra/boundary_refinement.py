"""
Dual-Branch Boundary Refinement Module (Post-Processing)

Branch 1: Learned Boundary Prediction (CNN)
Branch 2: Objectness Prior (Edge Detection)
Fusion  : Edge-guided confidence suppression
"""

import cv2
import numpy as np


def compute_edge_map(image_rgb):
    """
    image_rgb: H x W x 3 (uint8)
    return: edge map in [0, 1]
    """
    gray = cv2.cvtColor(image_rgb, cv2.COLOR_RGB2GRAY)
    edges = cv2.Canny(gray, threshold1=80, threshold2=160)
    edges = edges.astype(np.float32) / 255.0
    return edges


def refine_boundary(boundary_prob, image_rgb_small, alpha=0.8):
    """
    boundary_prob: H x W (e.g., 128x128)
    image_rgb_small: H x W x 3 (same resolution)
    alpha: strength of objectness guidance
    """
    edge_map = compute_edge_map(image_rgb_small)

    # Dual-branch fusion (shape-safe)
    refined = boundary_prob * (alpha * edge_map + (1 - alpha))

    return np.clip(refined, 0, 1)
