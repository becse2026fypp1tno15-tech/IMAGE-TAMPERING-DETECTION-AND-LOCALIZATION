"""
infer_with_image_level.py

Inference script for:
- Image-level tampering detection
- Pixel-level tampering localization
- Boundary visualization
"""

import os
import argparse
import numpy as np
from PIL import Image

import torch
import torch.nn.functional as F

from models.full_model import FullModel
from data.transforms import Preprocessor


# --------------------------------------------------
# Utility: save grayscale image
# --------------------------------------------------
def save_gray(array, path):
    array = np.clip(array, 0, 1)
    array = (array * 255).astype(np.uint8)
    Image.fromarray(array).save(path)


# --------------------------------------------------
# Main inference
# --------------------------------------------------
def run_inference(args):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # -------------------------
    # Load model
    # -------------------------
    model = FullModel(pretrained_backbone=False).to(device)

    ckpt = torch.load(args.checkpoint, map_location=device)
    if isinstance(ckpt, dict) and "model_state" in ckpt:
        model.load_state_dict(ckpt["model_state"])
    else:
        model.load_state_dict(ckpt)

    model.eval()
    print("✅ Model loaded")

    # -------------------------
    # Preprocessor (same as training)
    # -------------------------
    preproc = Preprocessor(input_size=args.input_size, train=False)

    # -------------------------
    # Load image
    # -------------------------
    img = Image.open(args.image).convert("RGB")

    # 🔑 FIX: dummy zero mask for inference
    dummy_mask = Image.new("L", img.size, 0)

    img_tensor, _, _ = preproc(img, dummy_mask)
    img_tensor = img_tensor.unsqueeze(0).to(device)

    # -------------------------
    # Forward pass
    # -------------------------
    with torch.no_grad():
        out = model(img_tensor, return_all=True)

    # -------------------------
    # Image-level prediction
    # -------------------------
    img_logit = out["image_logit"].view(1, 1)
    img_prob = torch.sigmoid(img_logit).item()
    img_label = "TAMPERED" if img_prob >= 0.5 else "AUTHENTIC"

    print("\n========== IMAGE-LEVEL RESULT ==========")
    print(f"Prediction : {img_label}")
    print(f"Confidence : {img_prob:.4f}")

    # -------------------------
    # Pixel-level mask
    # -------------------------
    mask_prob = torch.sigmoid(out["mask_logits_up"])[0, 0].cpu().numpy()
    mask_bin = (mask_prob >= 0.5).astype(np.float32)

    # -------------------------
    # Boundary map
    # -------------------------
    boundary_prob = torch.sigmoid(out["boundary_logits_local"])[0, 0].cpu().numpy()

    # -------------------------
    # Save outputs
    # -------------------------
    os.makedirs(args.out_dir, exist_ok=True)

    save_gray(mask_prob, os.path.join(args.out_dir, "mask_prob.png"))
    save_gray(mask_bin, os.path.join(args.out_dir, "mask_binary.png"))
    save_gray(boundary_prob, os.path.join(args.out_dir, "boundary.png"))

    # -------------------------
    # Overlay visualization
    # -------------------------
    img_np = np.array(img.resize((args.input_size, args.input_size)))
    overlay = img_np.copy()
    overlay[mask_bin > 0] = [255, 0, 0]

    Image.fromarray(overlay).save(
        os.path.join(args.out_dir, "overlay.png")
    )

    print("\n✅ Results saved to:", args.out_dir)
    print(" - mask_prob.png")
    print(" - mask_binary.png")
    print(" - boundary.png")
    print(" - overlay.png")


# --------------------------------------------------
# Args
# --------------------------------------------------
def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--image", type=str, required=True)
    p.add_argument("--checkpoint", type=str, required=True)
    p.add_argument("--out-dir", type=str, default="inference_output")
    p.add_argument("--input-size", type=int, default=512)
    return p.parse_args()


if __name__ == "__main__":
    args = parse_args()
    run_inference(args)
