import torch
from models.full_model import FullModel

def debug_run():
    print("\n[DEBUG] Initializing FullModel...\n")
    model = FullModel(pretrained_backbone=False)
    model.eval()

    # Dummy input
    x = torch.randn(1, 3, 512, 512)

    print("[DEBUG] Input shape:", x.shape)

    with torch.no_grad():
        out = model(x, return_all=True)

    print("\n========== DEBUG OUTPUT ==========\n")

    # 1️⃣ Pixel-level mask
    print("[DEBUG] mask_logits_up shape:",
          out["mask_logits_up"].shape)
    print("[DEBUG] mask_logits_up stats:",
          out["mask_logits_up"].min().item(),
          out["mask_logits_up"].max().item())

    # 2️⃣ Local mask (decoder resolution)
    print("[DEBUG] mask_logits_local shape:",
          out["mask_logits_local"].shape)

    # 3️⃣ Boundary outputs
    print("\n[DEBUG] Boundary multi-scale outputs:")
    for k, v in out["boundary_multi"].items():
        print(f"  {k}: {v.shape}")

    print("[DEBUG] boundary_logits_local shape:",
          out["boundary_logits_local"].shape)

    # 4️⃣ Final decoder feature (contrastive learning)
    print("\n[DEBUG] final_feat shape:",
          out["final_feat"].shape)

    # 5️⃣ Image-level prediction
    image_logit = out["image_logit"]
    image_prob = torch.sigmoid(image_logit)

    print("\n[DEBUG] image_logit:", image_logit.item())
    print("[DEBUG] image_prob (tampered):",
          image_prob.item())

    # 6️⃣ Backbone sanity
    print("\n[DEBUG] Backbone feature shapes:")
    for k, v in out["backbone_feats"].items():
        print(f"  {k}: {v.shape}")

    print("\n✅ DEBUG RUN COMPLETED SUCCESSFULLY\n")

if __name__ == "__main__":
    debug_run()
