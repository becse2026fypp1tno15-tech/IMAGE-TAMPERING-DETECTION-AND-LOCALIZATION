import os
from PIL import Image
from torch.utils.data import Dataset

from data.transforms import Preprocessor


class CASIA2ImageLevelDataset(Dataset):
    """
    CASIA2 dataset for JOINT pixel-level + image-level training.

    - Tp/  → tampered images (label = 1, mask available)
    - Au/  → authentic images (label = 0, no mask)
    """

    def __init__(self, root, input_size=512, train=True):
        self.root = root
        self.tp_dir = os.path.join(root, "Tp")
        self.au_dir = os.path.join(root, "Au")
        self.gt_dir = os.path.join(root, "CASIA 2 Groundtruth")

        self.preproc = Preprocessor(input_size=input_size, train=train)

        self.samples = []

        # ---------- Tampered images ----------
        gt_map = {}
        for fname in os.listdir(self.gt_dir):
            if fname.lower().endswith("_gt.png"):
                base = fname[:-7]  # remove "_gt.png"
                gt_map[base] = os.path.join(self.gt_dir, fname)

        for img_name in os.listdir(self.tp_dir):
            if img_name.lower().endswith((".jpg", ".png", ".jpeg", ".tif")):
                base = os.path.splitext(img_name)[0]
                if base in gt_map:
                    self.samples.append({
                        "img": os.path.join(self.tp_dir, img_name),
                        "mask": gt_map[base],
                        "label": 1
                    })

        # ---------- Authentic images ----------
        for img_name in os.listdir(self.au_dir):
            if img_name.lower().endswith((".jpg", ".png", ".jpeg", ".tif")):
                self.samples.append({
                    "img": os.path.join(self.au_dir, img_name),
                    "mask": None,
                    "label": 0
                })

        print(
            f"[CASIA2ImageLevel] Loaded {len(self.samples)} samples "
            f"(Tp + Au)"
        )

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        s = self.samples[idx]

        img = Image.open(s["img"]).convert("RGB")

        if s["mask"] is not None:
            mask = Image.open(s["mask"]).convert("L")
        else:
            # Authentic image → empty mask
            mask = Image.new("L", img.size, 0)

        img_t, mask_t, boundary_t = self.preproc(img, mask)

        return {
            "image": img_t,
            "mask": mask_t,
            "boundary": boundary_t,
            "label": s["label"],
            "img_path": s["img"]
        }


# -------------------------------------------------------
# Debug / sanity check (FAST & SAFE)
# -------------------------------------------------------
if __name__ == "__main__":
    print("\n[DEBUG] Running CASIA2ImageLevelDataset sanity check...\n")

    dataset = CASIA2ImageLevelDataset(
        root="../data/CASIA2",
        input_size=512,
        train=True
    )

    print(f"[DEBUG] Total samples: {len(dataset)}")

    num_tp = sum(1 for s in dataset.samples if s["label"] == 1)
    num_au = sum(1 for s in dataset.samples if s["label"] == 0)

    print(f"[DEBUG] Tampered (Tp): {num_tp}")
    print(f"[DEBUG] Authentic (Au): {num_au}")

    # ---- One tampered sample (FAST)
    tp_idx = next(i for i, s in enumerate(dataset.samples) if s["label"] == 1)
    tp_sample = dataset[tp_idx]

    print("\n[DEBUG] Example TAMPERED sample:")
    print("  image shape :", tp_sample["image"].shape)
    print("  mask shape  :", tp_sample["mask"].shape)
    print("  boundary    :", tp_sample["boundary"].shape)
    print("  label       :", tp_sample["label"])
    print("  img_path    :", tp_sample["img_path"])

    # ---- One authentic sample (FAST)
    au_idx = next(i for i, s in enumerate(dataset.samples) if s["label"] == 0)
    au_sample = dataset[au_idx]

    print("\n[DEBUG] Example AUTHENTIC sample:")
    print("  image shape :", au_sample["image"].shape)
    print("  mask shape  :", au_sample["mask"].shape)
    print("  boundary    :", au_sample["boundary"].shape)
    print("  label       :", au_sample["label"])
    print("  img_path    :", au_sample["img_path"])

    print("\n✅ CASIA2ImageLevelDataset DEBUG PASSED\n")
