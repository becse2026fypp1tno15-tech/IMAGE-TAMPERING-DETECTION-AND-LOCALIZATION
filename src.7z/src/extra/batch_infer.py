"""
batch_infer.py

Batch inference for image manipulation detection.

✔ Runs inference on images in a folder
✔ Supports limiting number of images (--max-images)
✔ Saves masks, boundaries, overlays
✔ Writes CSV summary (prediction + confidence)
"""

import os
import csv
import argparse
import numpy as np
from PIL import Image

import torch
import torch.nn.functional as F

from models.full_model import FullModel
from data.transforms import Preprocessor


# --------------------------------------------------
# Utilities
# --------------------------------------------------
def save_gray(array, path):
    array = np.clip(array, 0, 1)
    array = (array * 255).astype(np.uint8)
    Image.fromarray(array).save(path)


def is_image(fname):
    return fname.lower().endswith((".jpg", ".jpeg", ".png", ".tif", ".tiff"))


# --------------------------------------------------
# Batch inference
# --------------------------------------------------
def batch_infer(args):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # -------------------------
    # Load model
    # -------------------------
    model = FullModel(pretrained_backbone=False).to(device)

    ckpt = torch.load(args.checkpoint, map_location=device)
    if isinstance(ckpt, dict) and "model_state" in ckpt:
        model.load_state_dict(ckpt["model_state"])
    else:
        model.load_state_dict(ckpt)

    model.eval()
    print("✅ Model loaded")

    # -------------------------
    # Preprocessor
    # -------------------------
    preproc = Preprocessor(input_size=args.input_size, train=False)

    os.makedirs(args.out_dir, exist_ok=True)

    csv_path = os.path.join(args.out_dir, "results.csv")
    with open(csv_path, "w", newline="") as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(["image", "prediction", "confidence"])

        # -------------------------
        # Collect images
        # -------------------------
        image_files = sorted(
            f for f in os.listdir(args.in_dir) if is_image(f)
        )

        if args.max_images is not None:
            image_files = image_files[:args.max_images]

        print(f"🔍 Processing {len(image_files)} images")

        # -------------------------
        # Inference loop
        # -------------------------
        for idx, fname in enumerate(image_files):
            img_path = os.path.join(args.in_dir, fname)
            print(f"[{idx+1}/{len(image_files)}] {fname}")

            img = Image.open(img_path).convert("RGB")
            dummy_mask = Image.new("L", img.size, 0)

            img_tensor, _, _ = preproc(img, dummy_mask)
            img_tensor = img_tensor.unsqueeze(0).to(device)

            with torch.no_grad():
                out = model(img_tensor, return_all=True)

            # -------- Image-level prediction --------
            img_logit = out["image_logit"].view(1, 1)
            img_prob = torch.sigmoid(img_logit).item()
            img_label = "TAMPERED" if img_prob >= 0.5 else "AUTHENTIC"

            # -------- Pixel-level outputs --------
            mask_prob = torch.sigmoid(out["mask_logits_up"])[0, 0].cpu().numpy()
            mask_bin = (mask_prob >= 0.5).astype(np.float32)
            boundary_prob = torch.sigmoid(out["boundary_logits_local"])[0, 0].cpu().numpy()

            # -------- Save per-image folder --------
            base = os.path.splitext(fname)[0]
            out_img_dir = os.path.join(args.out_dir, base)
            os.makedirs(out_img_dir, exist_ok=True)

            save_gray(mask_prob, os.path.join(out_img_dir, "mask_prob.png"))
            save_gray(mask_bin, os.path.join(out_img_dir, "mask_binary.png"))
            save_gray(boundary_prob, os.path.join(out_img_dir, "boundary.png"))

            img_np = np.array(img.resize((args.input_size, args.input_size)))
            overlay = img_np.copy()
            overlay[mask_bin > 0] = [255, 0, 0]
            Image.fromarray(overlay).save(
                os.path.join(out_img_dir, "overlay.png")
            )

            # -------- Write CSV --------
            writer.writerow([fname, img_label, f"{img_prob:.4f}"])

    print("\n✅ Batch inference complete")
    print("📄 Results saved to:", csv_path)


# --------------------------------------------------
# Args
# --------------------------------------------------
def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--in-dir", type=str, required=True,
                   help="Folder containing images")
    p.add_argument("--checkpoint", type=str, required=True,
                   help="Path to trained model")
    p.add_argument("--out-dir", type=str, default="batch_results")
    p.add_argument("--input-size", type=int, default=512)
    p.add_argument("--max-images", type=int, default=None,
                   help="Maximum number of images to process")
    return p.parse_args()


if __name__ == "__main__":
    args = parse_args()
    batch_infer(args)
