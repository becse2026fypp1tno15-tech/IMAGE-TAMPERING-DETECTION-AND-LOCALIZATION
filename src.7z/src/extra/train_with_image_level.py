"""
train_with_image_level.py

Joint training:
- Pixel-level localization (base paper)
- Image-level classification (extension)

✔ Base-paper losses preserved
✔ Boundary GT always provided
✔ Image logit shape normalized
✔ FP32 only
✔ Safe for long training
"""

import os
import random
import argparse
from collections import defaultdict

import numpy as np
from tqdm import tqdm

import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader, random_split

from models.full_model import FullModel
from extra.casia2_imagelevel_dataset import CASIA2ImageLevelDataset
from losses.segmentation_losses import SegmentationLosses
from losses.contrastive_loss import sampler_contrastive_loss
from losses.boundary_sampler import sample_hard_examples


# --------------------------------------------------
# Utils
# --------------------------------------------------
def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


# --------------------------------------------------
# Train one epoch (BASE-PAPER FAITHFUL)
# --------------------------------------------------
def train_one_epoch(epoch, model, dataloader, optimizer, seg_loss_fn, device, cfg):
    model.train()
    running_loss = 0.0

    pbar = tqdm(
        dataloader,
        desc=f"Epoch {epoch}",
        leave=True,
        dynamic_ncols=True
    )

    for step, batch in enumerate(pbar):
        images = batch["image"].to(device)
        masks = batch["mask"].to(device)
        labels = batch["label"].float().to(device).view(-1, 1)

        boundaries_full = batch["boundary"].to(device)
        if boundaries_full.dim() == 3:
            boundaries_full = boundaries_full.unsqueeze(1)

        optimizer.zero_grad(set_to_none=True)

        out = model(images, return_all=True)

        # Normalize image logit shape
        img_logit = out["image_logit"].view(out["image_logit"].size(0), 1)

        boundary_gt_dict = {
            "b4": F.interpolate(boundaries_full, (32, 32), mode="nearest"),
            "b3": F.interpolate(boundaries_full, (64, 64), mode="nearest"),
            "b2": F.interpolate(boundaries_full, (128, 128), mode="nearest"),
        }

        L_mask, L_boundary, _, _ = seg_loss_fn(
            out["mask_logits_up"],
            masks,
            out["boundary_multi"],
            boundary_gt_dict
        )

        L_contrast, _ = sampler_contrastive_loss(
            features=out["final_feat"],
            mask_gt=masks,
            sampler_fn=sample_hard_examples,
            Z=cfg.Z,
            L=cfg.L,
            dilation=cfg.dilation,
            temperature=cfg.temperature,
            device=device
        )

        L_img = F.binary_cross_entropy_with_logits(img_logit, labels)

        L_total = (
            L_mask
            + L_boundary
            + cfg.lambda_c * L_contrast
            + cfg.lambda_i * L_img
        )

        if not torch.isfinite(L_total):
            continue

        L_total.backward()
        optimizer.step()

        running_loss += L_total.item()

        # Update progress bar ONLY (no print)
        pbar.set_postfix(
            loss=f"{running_loss / (step + 1):.4f}"
        )

    return {"L_total": running_loss / len(dataloader)}


# --------------------------------------------------
# Validation (image-level)
# --------------------------------------------------
def validate_image_level(model, dataloader, device):
    model.eval()
    correct = total = 0

    with torch.no_grad():
        for batch in dataloader:
            images = batch["image"].to(device)
            labels = batch["label"].to(device).view(-1, 1)

            out = model(images)
            img_logit = out["image_logit"].view(out["image_logit"].size(0), 1)

            preds = (torch.sigmoid(img_logit) > 0.5).long()

            correct += (preds == labels.long()).sum().item()
            total += labels.numel()

    return correct / (total + 1e-8)


# --------------------------------------------------
# Args
# --------------------------------------------------
def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--data-root", type=str, required=True)
    p.add_argument("--save-dir", type=str, default="../checkpoints_image")
    p.add_argument("--epochs", type=int, default=20)
    p.add_argument("--batch-size", type=int, default=4)
    p.add_argument("--lr", type=float, default=1e-4)
    p.add_argument("--weight-decay", type=float, default=1e-5)
    p.add_argument("--num-workers", type=int, default=4)
    p.add_argument("--val-split", type=float, default=0.1)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--Z", type=int, default=500)
    p.add_argument("--L", type=int, default=256)
    p.add_argument("--dilation", type=int, default=3)
    p.add_argument("--temperature", type=float, default=0.1)
    p.add_argument("--lambda-c", type=float, default=1.0, dest="lambda_c")
    p.add_argument("--lambda-i", type=float, default=0.1, dest="lambda_i")
    return p.parse_args()


# --------------------------------------------------
# Main
# --------------------------------------------------
def main(cfg):
    set_seed(cfg.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    os.makedirs(cfg.save_dir, exist_ok=True)

    dataset = CASIA2ImageLevelDataset(cfg.data_root, input_size=512, train=True)

    val_n = int(len(dataset) * cfg.val_split)
    train_n = len(dataset) - val_n
    train_set, val_set = random_split(dataset, [train_n, val_n])

    train_loader = DataLoader(
        train_set,
        batch_size=cfg.batch_size,
        shuffle=True,
        num_workers=cfg.num_workers
    )

    val_loader = DataLoader(
        val_set,
        batch_size=cfg.batch_size,
        shuffle=False
    )

    model = FullModel(pretrained_backbone=True).to(device)
    seg_loss_fn = SegmentationLosses(device=device)

    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=cfg.lr,
        weight_decay=cfg.weight_decay
    )

    best_acc = 0.0

    for epoch in range(cfg.epochs):
        avg_train = train_one_epoch(
            epoch, model, train_loader,
            optimizer, seg_loss_fn, device, cfg
        )

        acc = validate_image_level(model, val_loader, device)

        print(
            f"\n✅ Epoch {epoch} COMPLETED | "
            f"Train Loss={avg_train['L_total']:.4f} | "
            f"Image Acc={acc:.4f}\n"
        )

        if acc > best_acc:
            best_acc = acc
            torch.save(
                model.state_dict(),
                os.path.join(cfg.save_dir, "best_image_level.pth")
            )
            print("💾 Best model saved")

    print("🎉 Training finished. Best Image Acc:", best_acc)


if __name__ == "__main__":
    cfg = parse_args()
    main(cfg)
