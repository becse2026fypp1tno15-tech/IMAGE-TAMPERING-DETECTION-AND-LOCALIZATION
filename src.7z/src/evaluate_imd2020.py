#!/usr/bin/env python3
"""
evaluate_imd2020.py

Cross-test model (trained on CASIAv2) on IMD2020 dataset.

Base-paper compliant evaluation:
- fixed threshold = 0.5
- pixel-level Precision / Recall / F1 / IoU
- optional visualization (sample-N only)

Outputs:
<save_dir>/eval_out/imd2020/
 - imd2020_summary_fixed.json
 - imd2020_per_image_fixed.csv
 - vis/ (optional)
"""

import os
import argparse
import json
import csv
from pathlib import Path
from tqdm import tqdm

import numpy as np
from PIL import Image
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

import torch
from torch.utils.data import Dataset, DataLoader

# add src root
import sys
HERE = os.path.dirname(__file__)
if HERE not in sys.path:
    sys.path.insert(0, HERE)

from models.full_model import FullModel

IMG_NET_SIZE = 512
IMG_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}

# --------------------------------------------------
# Dataset
# --------------------------------------------------
class IMD2020Dataset(Dataset):
    """
    Each folder contains:
      - original: *_orig.*
      - tampered: *_0.*, *_1.*, ...
      - masks   : *_0_mask.*, *_1_mask.*
    """

    def __init__(self, root_dir):
        self.root = Path(root_dir)
        if not self.root.exists():
            raise RuntimeError(f"IMD2020 root not found: {root_dir}")

        self.items = []

        for folder in sorted(self.root.iterdir()):
            if not folder.is_dir():
                continue

            files = list(folder.iterdir())
            for f in files:
                if f.suffix.lower() not in IMG_EXTS:
                    continue
                if f.name.endswith("_orig" + f.suffix):
                    continue
                if "_mask" in f.stem:
                    continue

                mask = folder / (f.stem + "_mask" + f.suffix)
                if not mask.exists():
                    continue

                self.items.append({
                    "img": str(f),
                    "mask": str(mask),
                    "rel": str(f.relative_to(self.root))
                })

        if len(self.items) == 0:
            raise RuntimeError("No valid IMD2020 samples found.")

    def __len__(self):
        return len(self.items)

    def __getitem__(self, idx):
        rec = self.items[idx]

        img = Image.open(rec["img"]).convert("RGB")
        orig_w, orig_h = img.size

        inp = img.resize((IMG_NET_SIZE, IMG_NET_SIZE), Image.BILINEAR)
        arr = np.array(inp).astype(np.float32) / 255.0
        mean = np.array([0.485, 0.456, 0.406])
        std  = np.array([0.229, 0.224, 0.225])
        arr = (arr - mean) / std
        arr = np.transpose(arr, (2, 0, 1))
        img_tensor = torch.from_numpy(arr).float()

        m = Image.open(rec["mask"]).convert("L")
        m = m.resize((IMG_NET_SIZE, IMG_NET_SIZE), Image.NEAREST)
        mask = (np.array(m) > 127).astype(np.uint8)

        return {
            "image": img_tensor,
            "mask": mask,
            "orig_size": (orig_w, orig_h),
            "abs_path": rec["img"],
            "rel_path": rec["rel"]
        }


def collate_fn(batch):
    return {
        "image": torch.stack([b["image"] for b in batch]),
        "mask": [b["mask"] for b in batch],
        "orig_size": [b["orig_size"] for b in batch],
        "abs_path": [b["abs_path"] for b in batch],
        "rel_path": [b["rel_path"] for b in batch],
    }

# --------------------------------------------------
# Metrics
# --------------------------------------------------
def compute_metrics(pred, gt, eps=1e-8):
    tp = int((pred & gt).sum())
    fp = int((pred & (1 - gt)).sum())
    fn = int(((1 - pred) & gt).sum())

    prec = tp / (tp + fp + eps)
    rec  = tp / (tp + fn + eps)
    f1   = 2 * prec * rec / (prec + rec + eps)
    iou  = tp / (tp + fp + fn + eps)
    return prec, rec, f1, iou


def save_overlay(img_path, prob, bin_mask, out_path):
    img = np.array(Image.open(img_path).convert("RGB"))
    cmap = plt.get_cmap("jet")
    heat = (cmap(prob)[:, :, :3] * 255).astype(np.uint8)

    overlay = img.copy()
    idx = bin_mask.astype(bool)
    overlay[idx] = (0.5 * heat[idx] + 0.5 * img[idx]).astype(np.uint8)

    fig, ax = plt.subplots(1, 3, figsize=(15, 5))
    ax[0].imshow(img); ax[0].set_title("Original"); ax[0].axis("off")
    ax[1].imshow(prob, cmap="jet"); ax[1].set_title("Mask prob"); ax[1].axis("off")
    ax[2].imshow(overlay); ax[2].set_title("Overlay"); ax[2].axis("off")
    plt.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)

# --------------------------------------------------
# Main
# --------------------------------------------------
def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--data-root", required=True)
    p.add_argument("--ckpt", required=True)
    p.add_argument("--save-dir", default="../checkpoints")
    p.add_argument("--device", default="cuda")
    p.add_argument("--batch-size", type=int, default=16)
    p.add_argument("--num-workers", type=int, default=4)
    p.add_argument("--visualize", action="store_true")
    p.add_argument("--sample-n", type=int, default=10)
    return p.parse_args()


def main():
    args = parse_args()
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")

    out_dir = Path(args.save_dir) / "eval_out" / "imd2020"
    vis_dir = out_dir / "vis"
    out_dir.mkdir(parents=True, exist_ok=True)
    if args.visualize:
        vis_dir.mkdir(exist_ok=True)

    ds = IMD2020Dataset(args.data_root)
    loader = DataLoader(
        ds, batch_size=args.batch_size,
        shuffle=False, num_workers=args.num_workers,
        collate_fn=collate_fn
    )

    model = FullModel(pretrained_backbone=True).to(device)
    ckpt = torch.load(args.ckpt, map_location=device)
    model.load_state_dict(ckpt["model_state"] if "model_state" in ckpt else ckpt)
    model.eval()

    tp = fp = fn = 0
    per_image = []
    vis_count = 0
    threshold = 0.5

    with torch.no_grad():
        for batch in tqdm(loader, desc="Evaluating IMD2020"):
            imgs = batch["image"].to(device)
            masks = batch["mask"]
            sizes = batch["orig_size"]
            paths = batch["abs_path"]
            rels  = batch["rel_path"]

            out = model(imgs, return_all=True)
            probs = torch.sigmoid(out["mask_logits_up"]).cpu().numpy()[:, 0]

            for i in range(len(probs)):
                pw, ph = sizes[i]
                prob = Image.fromarray((probs[i] * 255).astype(np.uint8))
                prob = prob.resize((pw, ph), Image.BILINEAR)
                prob = np.array(prob) / 255.0

                gt = Image.fromarray(masks[i] * 255)
                gt = gt.resize((pw, ph), Image.NEAREST)
                gt = (np.array(gt) > 127).astype(np.uint8)

                bin_mask = (prob >= threshold).astype(np.uint8)

                p, r, f1, iou = compute_metrics(bin_mask, gt)
                per_image.append({
                    "image": rels[i],
                    "precision": p,
                    "recall": r,
                    "f1": f1,
                    "iou": iou
                })

                tp += int((bin_mask & gt).sum())
                fp += int((bin_mask & (1 - gt)).sum())
                fn += int(((1 - bin_mask) & gt).sum())

                if args.visualize and vis_count < args.sample_n:
                    out_img = vis_dir / f"sample_{vis_count:03d}.png"
                    save_overlay(paths[i], prob, bin_mask, out_img)
                    vis_count += 1

    precision = tp / (tp + fp + 1e-8)
    recall    = tp / (tp + fn + 1e-8)
    f1        = 2 * precision * recall / (precision + recall + 1e-8)
    iou       = tp / (tp + fp + fn + 1e-8)

    print("\n=== IMD2020 CROSS-TEST (BASE PAPER) ===")
    print(f"Images evaluated        : {len(ds)}")
    print(f"Precision @0.5          : {precision:.6f}")
    print(f"Recall    @0.5          : {recall:.6f}")
    print(f"F1-score  @0.5          : {f1:.6f}")
    print(f"IoU       @0.5          : {iou:.6f}")

    with open(out_dir / "imd2020_summary_fixed.json", "w") as f:
        json.dump({
            "dataset": "imd2020",
            "precision@0.5": precision,
            "recall@0.5": recall,
            "f1@0.5": f1,
            "iou@0.5": iou,
            "num_images": len(ds)
        }, f, indent=2)

    with open(out_dir / "imd2020_per_image_fixed.csv", "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=per_image[0].keys())
        writer.writeheader()
        writer.writerows(per_image)

    print("Saved results to        :", out_dir)


if __name__ == "__main__":
    main()
