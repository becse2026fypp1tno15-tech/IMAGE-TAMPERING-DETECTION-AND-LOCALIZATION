# src/evaluate.py
"""
Paper-style evaluation (per-image best-threshold sweep) for CASIA2.

Outputs (per-paper):
 - Mean Best-Precision
 - Mean Best-Recall
 - Mean Best-F1
 - Mean Best-IoU
 - Mean Best-Threshold

Usage examples (from src/):
  # evaluate best.pth on the same validation split used during training (~10%)
  python evaluate.py --data-root ../data/CASIA2 --ckpt ../checkpoints/best.pth --eval-split val

  # evaluate full dataset
  python evaluate.py --data-root ../data/CASIA2 --ckpt ../checkpoints/best.pth --eval-split full

  # evaluate all epoch checkpoints in a folder (saves one JSON per ckpt)
  python evaluate.py --data-root ../data/CASIA2 --ckpt all --save-dir ../checkpoints

Defaults are embedded to match typical layout in this repo.
"""
import os
import argparse
import json
import csv
from glob import glob
from tqdm import tqdm

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader, random_split

# ensure repo src root is on path (so imports work if run from src/)
import sys
HERE = os.path.dirname(__file__)
if HERE not in sys.path:
    sys.path.insert(0, HERE)

from data.casia2_dataset import CASIA2Dataset
from models.full_model import FullModel

# -------------------------
# helper functions
# -------------------------
def compute_prf_iou(pred_bin, gt_bin, eps=1e-8):
    pred = pred_bin.astype(np.uint8)
    gt = gt_bin.astype(np.uint8)
    tp = int((pred & gt).sum())
    fp = int((pred & (1 - gt)).sum())
    fn = int(((1 - pred) & gt).sum())
    prec = tp / (tp + fp + eps)
    rec = tp / (tp + fn + eps)
    f1 = 2 * prec * rec / (prec + rec + eps)
    inter = int((pred & gt).sum())
    union = int((pred | gt).sum())
    iou = inter / (union + eps)
    return prec, rec, f1, iou

def sweep_best_metrics(prob_map, gt_mask, thresholds):
    best_f1 = -1.0
    best_stats = (0.0, 0.0, 0.0, 0.0, 0.0)
    for t in thresholds:
        pred_bin = (prob_map >= t)
        prec, rec, f1, iou = compute_prf_iou(pred_bin, gt_mask)
        # maximize F1; tie-break on IoU (paper's approach)
        if (f1 > best_f1) or (abs(f1 - best_f1) < 1e-12 and iou > best_stats[3]):
            best_f1 = f1
            best_stats = (prec, rec, f1, iou, float(t))
    return {"precision": best_stats[0], "recall": best_stats[1], "f1": best_stats[2], "iou": best_stats[3], "best_thresh": best_stats[4]}

# -------------------------
# CLI
# -------------------------
def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--data-root", type=str, required=True,
                   help="Path to CASIA2 folder (contains Tp/ CASIA 2 Groundtruth/...)")
    p.add_argument("--ckpt", type=str, default="../checkpoints/best.pth",
                   help="Checkpoint path or 'all' to evaluate all ckpt_epoch_*.pth in save-dir")
    p.add_argument("--save-dir", type=str, default="../checkpoints",
                   help="Where to write eval outputs (and where ckpts are when --ckpt all)")
    p.add_argument("--eval-split", type=str, choices=["val", "full"], default="val",
                   help="Evaluate on 'val' split (same as training) or on the full dataset")
    p.add_argument("--thresh-steps", type=int, default=200,
                   help="Number of thresholds to sweep between 0..1")
    p.add_argument("--num-workers", type=int, default=4)
    p.add_argument("--device", type=str, default="cuda")
    return p.parse_args()

# -------------------------
# core evaluate function
# -------------------------
def evaluate_checkpoint(model, ckpt_path, device, loader, thresholds, out_dir):
    # load checkpoint robustly
    ckpt = torch.load(ckpt_path, map_location=device)
    if isinstance(ckpt, dict) and "model_state" in ckpt:
        model.load_state_dict(ckpt["model_state"])
    else:
        model.load_state_dict(ckpt)
    model.to(device)
    model.eval()
    print("Loaded checkpoint:", ckpt_path)

    per_image = []
    sum_prec = sum_rec = sum_f1 = sum_iou = sum_thresh = 0.0
    n = 0

    with torch.no_grad():
        for idx, sample in enumerate(tqdm(loader, desc="Evaluating")):
            img = sample["image"].to(device)          # (1,3,H,W)
            gt_mask = sample["mask"].squeeze(0).squeeze(0).cpu().numpy().astype(np.uint8)  # (H,W)

            out = model(img, return_all=True)
            logits = out.get("mask_logits_up", None)
            if logits is None:
                # fallback naming
                logits = out[list(out.keys())[0]]
            probs = torch.sigmoid(logits).squeeze(0).squeeze(0).cpu().numpy()  # (H,W)

            stats = sweep_best_metrics(probs, gt_mask, thresholds)

            per_image.append({
                "idx": int(idx),
                "best_thresh": float(stats["best_thresh"]),
                "precision": float(stats["precision"]),
                "recall": float(stats["recall"]),
                "f1": float(stats["f1"]),
                "iou": float(stats["iou"])
            })

            sum_prec += stats["precision"]
            sum_rec += stats["recall"]
            sum_f1 += stats["f1"]
            sum_iou += stats["iou"]
            sum_thresh += stats["best_thresh"]
            n += 1

    mean_prec = sum_prec / n
    mean_rec = sum_rec / n
    mean_f1 = sum_f1 / n
    mean_iou = sum_iou / n
    mean_thresh = sum_thresh / n

    summary = {
        "val_samples": n,
        "mean_best_precision": mean_prec,
        "mean_best_recall": mean_rec,
        "mean_best_f1": mean_f1,
        "mean_best_iou": mean_iou,
        "mean_best_threshold": mean_thresh,
        "threshold_steps": len(thresholds),
        "ckpt": os.path.abspath(ckpt_path)
    }

    # save outputs
    os.makedirs(out_dir, exist_ok=True)
    base_name = os.path.splitext(os.path.basename(ckpt_path))[0]
    json_path = os.path.join(out_dir, f"eval_summary_{base_name}.json")
    csv_path = os.path.join(out_dir, f"eval_per_image_{base_name}.csv")

    with open(json_path, "w") as f:
        json.dump(summary, f, indent=2)

    with open(csv_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["idx", "best_thresh", "precision", "recall", "f1", "iou"])
        writer.writeheader()
        for r in per_image:
            writer.writerow(r)

    # pretty print
    print("\n=== EVAL (per-image best-threshold) ===")
    print(f"Val samples: {n}")
    print(f"Mean Best-Precision : {mean_prec:.4f}")
    print(f"Mean Best-Recall    : {mean_rec:.4f}")
    print(f"Mean Best-F1        : {mean_f1:.4f}")
    print(f"Mean Best-IoU       : {mean_iou:.4f}")
    print(f"Mean Best-Threshold : {mean_thresh:.4f}")
    print(f"Saved JSON: {json_path}")
    print(f"Saved CSV:  {csv_path}")

    return summary, per_image

# -------------------------
# main entry
# -------------------------
def main():
    args = parse_args()
    device = torch.device(args.device if torch.cuda.is_available() and args.device == "cuda" else "cpu")

    # ensure absolute paths and output dir
    data_root = os.path.abspath(args.data_root)
    save_dir = os.path.abspath(args.save_dir)
    out_dir = os.path.join(save_dir, "eval_out")
    os.makedirs(out_dir, exist_ok=True)

    print("Device:", device)
    print("Data root:", data_root)
    print("Checkpoint:", args.ckpt)
    print("Eval split:", args.eval_split)

    # dataset
    dataset = CASIA2Dataset(root=data_root, input_size=512, train=False)

    # choose loader: val split or full dataset
    if args.eval_split == "val":
        N = len(dataset)
        val_n = int(N * 0.1)
        train_n = N - val_n
        # reproduce the same split as training (seed=42)
        _, val_set = random_split(dataset, [train_n, val_n], generator=torch.Generator().manual_seed(42))
        loader = DataLoader(val_set, batch_size=1, shuffle=False, num_workers=args.num_workers, pin_memory=True)
        print(f"Evaluating on validation split: {len(val_set)} samples")
    else:
        loader = DataLoader(dataset, batch_size=1, shuffle=False, num_workers=args.num_workers, pin_memory=True)
        print(f"Evaluating on full dataset: {len(dataset)} samples")

    # model skeleton (weights loaded per-ckpt)
    model = FullModel(pretrained_backbone=True)
    thresholds = np.linspace(0.0, 1.0, args.thresh_steps)

    # evaluate single ckpt or all ckpts
    if args.ckpt.lower() == "all":
        # find ckpt_epoch_*.pth (or any pth) in save_dir
        ckpt_files = sorted(glob(os.path.join(save_dir, "ckpt_epoch_*.pth")))
        if not ckpt_files:
            # fallback to any pth
            ckpt_files = sorted(glob(os.path.join(save_dir, "*.pth")))
        if not ckpt_files:
            raise FileNotFoundError(f"No checkpoints found in {save_dir}")
        print(f"Found {len(ckpt_files)} checkpoints to evaluate.")
        all_summaries = {}
        for ckpt_path in ckpt_files:
            # instantiate fresh model for each load to avoid unexpected state sharing
            model_eval = FullModel(pretrained_backbone=True).to(device)
            summary, per_image = evaluate_checkpoint(model_eval, ckpt_path, device, loader, thresholds, out_dir)
            all_summaries[os.path.basename(ckpt_path)] = summary
        # save aggregated summaries
        agg_json = os.path.join(out_dir, "eval_all_checkpoints_summary.json")
        with open(agg_json, "w") as f:
            json.dump(all_summaries, f, indent=2)
        print(f"\nSaved aggregated summary for all ckpts: {agg_json}")

    else:
        ckpt_path = os.path.abspath(args.ckpt)
        if not os.path.exists(ckpt_path):
            raise FileNotFoundError(f"Checkpoint not found: {ckpt_path}")
        model.to(device)
        evaluate_checkpoint(model, ckpt_path, device, loader, thresholds, out_dir)

if __name__ == "__main__":
    main()
